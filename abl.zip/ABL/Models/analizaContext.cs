﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace ABL.Models
{
    public partial class analizaContext : DbContext
    {
        public analizaContext()
        {
        }

        public analizaContext(DbContextOptions<analizaContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Abl> Abl { get; set; }
        public virtual DbSet<AnalizaUpijanja> AnalizaUpijanja { get; set; }
        public virtual DbSet<AnalizaUpijanjaRavna> AnalizaUpijanjaRavna { get; set; }
        public virtual DbSet<ApsorcijaRetencija> ApsorcijaRetencija { get; set; }
        public virtual DbSet<Lutka> Lutka { get; set; }
        public virtual DbSet<Osoba> Osoba { get; set; }
        public virtual DbSet<Proizvod> Proizvod { get; set; }
        public virtual DbSet<Velicina> Velicina { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=DESKTOP-8C8KH2F;Initial Catalog=analiza;Integrated Security=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("ProductVersion", "2.2.6-servicing-10079");

            modelBuilder.Entity<Abl>(entity =>
            {
                entity.HasKey(e => e.IdAbl);

                entity.Property(e => e.IdAbl).HasColumnName("id_abl");

                entity.Property(e => e.Datum)
                    .HasColumnName("datum")
                    .HasColumnType("datetime");

                entity.Property(e => e.FkOsoba).HasColumnName("fk_osoba");

                entity.Property(e => e.FkPolozaj).HasColumnName("fk_polozaj");

                entity.Property(e => e.FkProizvod).HasColumnName("fk_proizvod");

                entity.Property(e => e.FkVelicina).HasColumnName("fk_velicina");

                entity.Property(e => e.Komentar)
                    .HasColumnName("komentar")
                    .HasMaxLength(50);

                entity.Property(e => e.Masa)
                    .IsRequired()
                    .HasColumnName("masa")
                    .HasMaxLength(10);

                entity.Property(e => e.MasaNakonCurenja)
                    .IsRequired()
                    .HasColumnName("masa_nakon_curenja")
                    .HasMaxLength(10);

                entity.Property(e => e.MasaUpijene)
                    .IsRequired()
                    .HasColumnName("masa_upijene")
                    .HasMaxLength(10);

                entity.Property(e => e.MinStupanjZastite)
                    .IsRequired()
                    .HasColumnName("min_stupanj_zastite")
                    .HasMaxLength(10);

                entity.Property(e => e.StupanjZastite)
                    .IsRequired()
                    .HasColumnName("stupanj_zastite")
                    .HasMaxLength(10);

               

                entity.HasOne(d => d.FkOsobaNavigation)
                    .WithMany(p => p.Abl)
                    .HasForeignKey(d => d.FkOsoba)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Abl_Osoba1");

                entity.HasOne(d => d.FkPolozajNavigation)
                    .WithMany(p => p.Abl)
                    .HasForeignKey(d => d.FkPolozaj)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Abl_Lutka");

                entity.HasOne(d => d.FkProizvodNavigation)
                    .WithMany(p => p.Abl)
                    .HasForeignKey(d => d.FkProizvod)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Abl_Proizvod");

                entity.HasOne(d => d.FkVelicinaNavigation)
                    .WithMany(p => p.Abl)
                    .HasForeignKey(d => d.FkVelicina)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Abl_Velicina");
            });

            modelBuilder.Entity<AnalizaUpijanja>(entity =>
            {
                entity.HasKey(e => e.IdAnalizaUpijanja);

                entity.ToTable("Analiza_upijanja");

                entity.Property(e => e.IdAnalizaUpijanja).HasColumnName("id_analiza_upijanja");

                entity.Property(e => e.CetvrtoUpijanje)
                    .HasColumnName("cetvrto_upijanje")
                    .HasMaxLength(10);

                entity.Property(e => e.Datum)
                    .HasColumnName("datum")
                    .HasColumnType("datetime");

                entity.Property(e => e.DrugoUpijanje)
                    .HasColumnName("drugo_upijanje")
                    .HasMaxLength(10);

                entity.Property(e => e.FkKorisnik).HasColumnName("fk_korisnik");

                entity.Property(e => e.FkProizvod).HasColumnName("fk_proizvod");

                entity.Property(e => e.FkVelicina).HasColumnName("fk_velicina");

                entity.Property(e => e.Komentar)
                    .HasColumnName("komentar")
                    .HasMaxLength(10);

                entity.Property(e => e.Masa)
                    .IsRequired()
                    .HasColumnName("masa")
                    .HasMaxLength(10);

                entity.Property(e => e.Povrat)
                    .HasColumnName("povrat")
                    .HasMaxLength(10);

                entity.Property(e => e.PrvoUpijanje)
                    .HasColumnName("prvo_upijanje")
                    .HasMaxLength(10);

                entity.Property(e => e.TMaxCetri)
                    .HasColumnName("t_max_cetri")
                    .HasMaxLength(10);

                entity.Property(e => e.TMaxDva)
                    .HasColumnName("t_max_dva")
                    .HasMaxLength(10);

                entity.Property(e => e.TMaxJedan)
                    .HasColumnName("t_max_jedan")
                    .HasMaxLength(10);

                entity.Property(e => e.TMaxTri)
                    .HasColumnName("t_max_tri")
                    .HasMaxLength(10);

                entity.Property(e => e.TPovrat)
                    .HasColumnName("t_povrat")
                    .HasMaxLength(10);

                entity.Property(e => e.TreceUpijanje)
                    .HasColumnName("trece_upijanje")
                    .HasMaxLength(10);

                entity.Property(e => e.Vrijeme)
                    .HasColumnName("vrijeme")
                    .HasColumnType("date");

                entity.HasOne(d => d.FkKorisnikNavigation)
                    .WithMany(p => p.AnalizaUpijanja)
                    .HasForeignKey(d => d.FkKorisnik)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Analiza_upijanja_Osoba");

                entity.HasOne(d => d.FkProizvodNavigation)
                    .WithMany(p => p.AnalizaUpijanja)
                    .HasForeignKey(d => d.FkProizvod)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Analiza_upijanja_Proizvod");

                entity.HasOne(d => d.FkVelicinaNavigation)
                    .WithMany(p => p.AnalizaUpijanja)
                    .HasForeignKey(d => d.FkVelicina)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Analiza_upijanja_Velicina");


            });

            modelBuilder.Entity<AnalizaUpijanjaRavna>(entity =>
            {
                entity.HasKey(e => e.IdAnalizaUpijanjaRavna);

                entity.ToTable("Analiza_upijanja_ravna");

                entity.Property(e => e.IdAnalizaUpijanjaRavna).HasColumnName("id_analiza_upijanja_ravna");

                entity.Property(e => e.CetvrtoUpijanje)
                    .HasColumnName("cetvrto_upijanje")
                    .HasMaxLength(10);

                entity.Property(e => e.Datum)
                    .HasColumnName("datum")
                    .HasColumnType("datetime");

                entity.Property(e => e.DrugoUpijanje)
                    .HasColumnName("drugo_upijanje")
                    .HasMaxLength(10);

                entity.Property(e => e.FkKorisnik).HasColumnName("fk_korisnik");

                entity.Property(e => e.FkProizvod).HasColumnName("fk_proizvod");

                entity.Property(e => e.FkVelicina).HasColumnName("fk_velicina");

                entity.Property(e => e.Komentar)
                    .HasColumnName("komentar")
                    .HasMaxLength(10);

                entity.Property(e => e.Masa)
                    .IsRequired()
                    .HasColumnName("masa")
                    .HasMaxLength(10);

                entity.Property(e => e.Povrat)
                    .HasColumnName("povrat")
                    .HasMaxLength(10);

                entity.Property(e => e.PrvoUpijanje)
                    .HasColumnName("prvo_upijanje")
                    .HasMaxLength(10);

               

                entity.Property(e => e.TreceUpijanje)
                    .HasColumnName("trece_upijanje")
                    .HasMaxLength(10);

               

                entity.HasOne(d => d.FkKorisnikNavigation)
                    .WithMany(p => p.AnalizaUpijanjaRavna)
                    .HasForeignKey(d => d.FkKorisnik)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Analiza_upijanja_ravna_Osoba");

                entity.HasOne(d => d.FkProizvodNavigation)
                    .WithMany(p => p.AnalizaUpijanjaRavna)
                    .HasForeignKey(d => d.FkProizvod)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Analiza_upijanja_ravna_Proizvod");

                entity.HasOne(d => d.FkVelicinaNavigation)
                    .WithMany(p => p.AnalizaUpijanjaRavna)
                    .HasForeignKey(d => d.FkVelicina)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Analiza_upijanja_ravna_Velicina");
            });

            modelBuilder.Entity<ApsorcijaRetencija>(entity =>
            {
                entity.HasKey(e => e.IdApsorpcijaRetencija);

                entity.ToTable("Apsorcija_retencija");

                entity.Property(e => e.IdApsorpcijaRetencija).HasColumnName("id_apsorpcija_retencija");

                entity.Property(e => e.Apsorpcija)
                    .IsRequired()
                    .HasColumnName("apsorpcija")
                    .HasMaxLength(10);

                entity.Property(e => e.Datum)
                    .HasColumnName("datum")
                    .HasColumnType("datetime");

                entity.Property(e => e.FkKorisnik).HasColumnName("fk_korisnik");

                entity.Property(e => e.FkProizvod).HasColumnName("fk_proizvod");

                entity.Property(e => e.FkVelicina).HasColumnName("fk_velicina");

                entity.Property(e => e.FkLutka).HasColumnName("fk_lutka");


                entity.Property(e => e.Komentar)
                    .HasColumnName("komentar")
                    .HasMaxLength(50);

                entity.Property(e => e.MasaNakonCentrifugiranja)
                    .IsRequired()
                    .HasColumnName("masa_nakon_centrifugiranja")
                    .HasMaxLength(10);

                entity.Property(e => e.MasaNakonCijedjenja)
                    .IsRequired()
                    .HasColumnName("masa_nakon_cijedjenja")
                    .HasMaxLength(10);

                entity.Property(e => e.MasaSuhePelene)
                    .IsRequired()
                    .HasColumnName("masa_suhe_pelene")
                    .HasMaxLength(10);

                entity.Property(e => e.MaxApsorpcija)
                    .IsRequired()
                    .HasColumnName("max_apsorpcija")
                    .HasMaxLength(10);

                entity.Property(e => e.MaxRetencija)
                    .IsRequired()
                    .HasColumnName("max_retencija")
                    .HasMaxLength(10);

                entity.Property(e => e.MinApsorpcija)
                    .IsRequired()
                    .HasColumnName("min_apsorpcija")
                    .HasMaxLength(10);

                entity.Property(e => e.MinRetencija)
                    .IsRequired()
                    .HasColumnName("min_retencija")
                    .HasMaxLength(10);

                entity.Property(e => e.Retencija)
                    .IsRequired()
                    .HasColumnName("retencija")
                    .HasMaxLength(10);

               

         

                entity.HasOne(d => d.FkKorisnikNavigation)
                    .WithMany(p => p.ApsorcijaRetencija)
                    .HasForeignKey(d => d.FkKorisnik)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Apsorcija_retencija_Osoba");

                entity.HasOne(d => d.FkProizvodNavigation)
                    .WithMany(p => p.ApsorcijaRetencija)
                    .HasForeignKey(d => d.FkProizvod)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Apsorcija_retencija_Proizvod");

                entity.HasOne(d => d.FkVelicinaNavigation)
                    .WithMany(p => p.ApsorcijaRetencija)
                    .HasForeignKey(d => d.FkVelicina)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Apsorcija_retencija_Velicina");

               

                entity.HasOne(d => d.FkPolozajNavigation)
                 .WithMany(p => p.ApsorcijaRetencija)
                 .HasForeignKey(d => d.FkLutka)
                 .OnDelete(DeleteBehavior.ClientSetNull)
                 .HasConstraintName("FK_Apsorcija_retencija_Lutka");

                
            });

            modelBuilder.Entity<Lutka>(entity =>
            {
                entity.HasKey(e => e.IdLutke);

                entity.Property(e => e.IdLutke).HasColumnName("id_lutke");

                entity.Property(e => e.PolozajLutke)
                    .IsRequired()
                    .HasColumnName("polozaj_lutke")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Osoba>(entity =>
            {
                entity.HasKey(e => e.IdOsoba);

                entity.Property(e => e.IdOsoba).HasColumnName("id_osoba");

                entity.Property(e => e.Ime_prezime)
                    .IsRequired()
                    .HasColumnName("Ime_prezime")
                    .HasMaxLength(10);

                entity.Property(e => e.KorisnickoIme)
                    .IsRequired()
                    .HasColumnName("korisnicko_ime")
                    .HasMaxLength(10);

                entity.Property(e => e.Lozinka)
                    .IsRequired()
                    .HasColumnName("lozinka")
                    .HasMaxLength(10);

                entity.Property(e => e.Status).HasColumnName("status");
            });

            modelBuilder.Entity<Proizvod>(entity =>
            {
                entity.HasKey(e => e.IdProizvoda);

                entity.Property(e => e.IdProizvoda).HasColumnName("id_proizvoda");

                entity.Property(e => e.Proizvod1)
                    .IsRequired()
                    .HasColumnName("proizvod")
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Velicina>(entity =>
            {
                entity.HasKey(e => e.IdVelicine);

                entity.Property(e => e.IdVelicine)
                    .HasColumnName("id_velicine")
                    .ValueGeneratedNever();

                entity.Property(e => e.Velicina1)
                    .IsRequired()
                    .HasColumnName("velicina")
                    .HasMaxLength(10);
            });
        }
    }
}
