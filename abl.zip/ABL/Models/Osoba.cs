﻿using System;
using System.Collections.Generic;

namespace ABL.Models
{
    public partial class Osoba
    {
        public Osoba()
        {
            Abl = new HashSet<Abl>();
            AnalizaUpijanja = new HashSet<AnalizaUpijanja>();
            AnalizaUpijanjaRavna = new HashSet<AnalizaUpijanjaRavna>();
            ApsorcijaRetencija = new HashSet<ApsorcijaRetencija>();
        }

        public int IdOsoba { get; set; }
        public string Ime_prezime { get; set; }
        public string KorisnickoIme { get; set; }
        public string Lozinka { get; set; }
        public bool Status { get; set; }

        public virtual ICollection<Abl> Abl { get; set; }
        public virtual ICollection<AnalizaUpijanja> AnalizaUpijanja { get; set; }
        public virtual ICollection<AnalizaUpijanjaRavna> AnalizaUpijanjaRavna { get; set; }
        public virtual ICollection<ApsorcijaRetencija> ApsorcijaRetencija { get; set; }
    }
}
