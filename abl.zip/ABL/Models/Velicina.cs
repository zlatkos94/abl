﻿using System;
using System.Collections.Generic;

namespace ABL.Models
{
    public partial class Velicina
    {
        public Velicina()
        {
            Abl = new HashSet<Abl>();
            AnalizaUpijanja = new HashSet<AnalizaUpijanja>();
            AnalizaUpijanjaRavna = new HashSet<AnalizaUpijanjaRavna>();
            ApsorcijaRetencija = new HashSet<ApsorcijaRetencija>();
        }

        public int IdVelicine { get; set; }
        public string Velicina1 { get; set; }

        public virtual ICollection<Abl> Abl { get; set; }
        public virtual ICollection<AnalizaUpijanja> AnalizaUpijanja { get; set; }
        public virtual ICollection<AnalizaUpijanjaRavna> AnalizaUpijanjaRavna { get; set; }
        public virtual ICollection<ApsorcijaRetencija> ApsorcijaRetencija { get; set; }
    }
}
