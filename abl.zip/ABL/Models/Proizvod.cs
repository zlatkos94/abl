﻿using System;
using System.Collections.Generic;

namespace ABL.Models
{
    public partial class Proizvod
    {
        public Proizvod()
        {
            Abl = new HashSet<Abl>();
            AnalizaUpijanja = new HashSet<AnalizaUpijanja>();
            AnalizaUpijanjaRavna = new HashSet<AnalizaUpijanjaRavna>();
            ApsorcijaRetencija = new HashSet<ApsorcijaRetencija>();
        }

        public int IdProizvoda { get; set; }
        public string Proizvod1 { get; set; }

        public virtual ICollection<Abl> Abl { get; set; }
        public virtual ICollection<AnalizaUpijanja> AnalizaUpijanja { get; set; }
        public virtual ICollection<AnalizaUpijanjaRavna> AnalizaUpijanjaRavna { get; set; }
        public virtual ICollection<ApsorcijaRetencija> ApsorcijaRetencija { get; set; }
    }
}
