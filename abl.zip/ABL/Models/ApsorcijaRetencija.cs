﻿using System;
using System.Collections.Generic;

namespace ABL.Models
{
    public partial class ApsorcijaRetencija
    {
        public int IdApsorpcijaRetencija { get; set; }
        public DateTime Datum { get; set; }
        public string MasaSuhePelene { get; set; }
        public string MasaNakonCijedjenja { get; set; }
        public string Apsorpcija { get; set; }
        public string MinApsorpcija { get; set; }
        public string MaxApsorpcija { get; set; }
        public string MasaNakonCentrifugiranja { get; set; }
        public string Retencija { get; set; }
        public string MinRetencija { get; set; }
        public string MaxRetencija { get; set; }
        public int FkKorisnik { get; set; }
        public int FkVelicina { get; set; }
        public int FkLutka { get; set; }

        public int FkProizvod { get; set; }
        public string Komentar { get; set; }
       

        public virtual Osoba FkKorisnikNavigation { get; set; }
        public virtual Proizvod FkProizvodNavigation { get; set; }
        public virtual Velicina FkVelicinaNavigation { get; set; }

        public virtual Lutka FkPolozajNavigation { get; set; }

    }
}
