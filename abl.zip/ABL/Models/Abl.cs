﻿using System;
using System.Collections.Generic;

namespace ABL.Models
{
    public partial class Abl
    {
        public int IdAbl { get; set; }
        public DateTime Datum { get; set; }
        public string Masa { get; set; }
        public string MasaNakonCurenja { get; set; }
        public string MasaUpijene { get; set; }
        public string StupanjZastite { get; set; }
        public int FkOsoba { get; set; }
        public string Komentar { get; set; }
        public string MinStupanjZastite { get; set; }
        public int FkVelicina { get; set; }
        public int FkPolozaj { get; set; }
        public int FkProizvod { get; set; }

        public virtual Osoba FkOsobaNavigation { get; set; }
        public virtual Lutka FkPolozajNavigation { get; set; }
        public virtual Proizvod FkProizvodNavigation { get; set; }
        public virtual Velicina FkVelicinaNavigation { get; set; }
    }
}
