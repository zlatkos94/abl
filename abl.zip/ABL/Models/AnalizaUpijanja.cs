﻿using System;
using System.Collections.Generic;

namespace ABL.Models
{
    public partial class AnalizaUpijanja
    {
        public int IdAnalizaUpijanja { get; set; }
        public DateTime Datum { get; set; }
        public DateTime? Vrijeme { get; set; }
        public int FkVelicina { get; set; }
        public int FkProizvod { get; set; }
        public int FkKorisnik { get; set; }
        public string Masa { get; set; }
        public string PrvoUpijanje { get; set; }
        public string DrugoUpijanje { get; set; }
        public string TreceUpijanje { get; set; }
        public string CetvrtoUpijanje { get; set; }
        public string Povrat { get; set; }
        public string Komentar { get; set; }
        public string TMaxJedan { get; set; }
        public string TMaxDva { get; set; }
        public string TMaxTri { get; set; }
        public string TMaxCetri { get; set; }
        public string TPovrat { get; set; }

        public virtual Osoba FkKorisnikNavigation { get; set; }
        public virtual Proizvod FkProizvodNavigation { get; set; }
        public virtual Velicina FkVelicinaNavigation { get; set; }
    }
}
