﻿using System;
using System.Collections.Generic;

namespace ABL.Models
{
    public partial class Lutka
    {
        public Lutka()
        {
            Abl = new HashSet<Abl>();
            ApsorcijaRetencija = new HashSet<ApsorcijaRetencija>();
        }

        public int IdLutke { get; set; }
        public string PolozajLutke { get; set; }

        public virtual ICollection<Abl> Abl { get; set; }
        public virtual ICollection<ApsorcijaRetencija> ApsorcijaRetencija { get; set; }

    }
}
