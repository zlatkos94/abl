﻿namespace ABL
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button4 = new System.Windows.Forms.Button();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.button7 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button2 = new System.Windows.Forms.Button();
            this.analizaDataSet8 = new ABL.analizaDataSet8();
            this.osobaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.osobaTableAdapter = new ABL.analizaDataSet8TableAdapters.OsobaTableAdapter();
            this.analizaDataSet9 = new ABL.analizaDataSet9();
            this.osobaBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.osobaTableAdapter1 = new ABL.analizaDataSet9TableAdapters.OsobaTableAdapter();
            this.analizaDataSet10 = new ABL.analizaDataSet10();
            this.osobaBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.osobaTableAdapter2 = new ABL.analizaDataSet10TableAdapters.OsobaTableAdapter();
            this.analizaDataSet11 = new ABL.analizaDataSet11();
            this.osobaBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.osobaTableAdapter3 = new ABL.analizaDataSet11TableAdapters.OsobaTableAdapter();
            this.analizaDataSet12 = new ABL.analizaDataSet12();
            this.osobaBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.osobaTableAdapter4 = new ABL.analizaDataSet12TableAdapters.OsobaTableAdapter();
            this.backgroundWorker1 = new System.ComponentModel.BackgroundWorker();
            this.analizaDataSet13 = new ABL.analizaDataSet13();
            this.ablBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.ablTableAdapter = new ABL.analizaDataSet13TableAdapters.AblTableAdapter();
            this.analizaDataSet18 = new ABL.analizaDataSet18();
            this.apsorcijaretencijaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.apsorcija_retencijaTableAdapter = new ABL.analizaDataSet18TableAdapters.Apsorcija_retencijaTableAdapter();
            this.analizaDataSet22 = new ABL.analizaDataSet22();
            this.analizaupijanjaravnaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.analiza_upijanja_ravnaTableAdapter = new ABL.analizaDataSet22TableAdapters.Analiza_upijanja_ravnaTableAdapter();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.button8 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.osobaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.osobaBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.osobaBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.osobaBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.osobaBindingSource4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ablBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.apsorcijaretencijaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaupijanjaravnaBindingSource)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tabControl1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1535, 781);
            this.panel1.TabIndex = 0;
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1535, 781);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Transparent;
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.textBox4);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.dataGridView2);
            this.tabPage1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1527, 752);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "ABL ZUIKO ";
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button3.Location = new System.Drawing.Point(1316, 21);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(181, 42);
            this.button3.TabIndex = 3;
            this.button3.Text = "Povratak na prijavu";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(217, 41);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(169, 22);
            this.textBox4.TabIndex = 2;
            this.textBox4.TextChanged += new System.EventHandler(this.TextBox4_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(60, 41);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(139, 20);
            this.label4.TabIndex = 1;
            this.label4.Text = "Pretraga po imenu";
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(3, 85);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(1521, 711);
            this.dataGridView2.TabIndex = 0;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridView2_CellContentClick);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button4);
            this.tabPage2.Controls.Add(this.textBox5);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.dataGridView3);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1527, 752);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "APSORPCIJA RETENCIJA";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button4.Location = new System.Drawing.Point(1316, 21);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(181, 42);
            this.button4.TabIndex = 3;
            this.button4.Text = "Povratak na prijavu";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.Button4_Click);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(217, 41);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(170, 22);
            this.textBox5.TabIndex = 2;
            this.textBox5.TextChanged += new System.EventHandler(this.TextBox5_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(60, 41);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(139, 20);
            this.label5.TabIndex = 1;
            this.label5.Text = "Pretraga po imenu";
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Location = new System.Drawing.Point(3, 85);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(1521, 711);
            this.dataGridView3.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.textBox6);
            this.tabPage3.Controls.Add(this.label6);
            this.tabPage3.Controls.Add(this.button6);
            this.tabPage3.Controls.Add(this.dataGridView4);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(1527, 752);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "ANALIZA UPIJANJA - RAVNA";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(217, 41);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(170, 22);
            this.textBox6.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(60, 41);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(139, 20);
            this.label6.TabIndex = 2;
            this.label6.Text = "Pretraga po imenu";
            // 
            // button6
            // 
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button6.Location = new System.Drawing.Point(1316, 21);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(181, 42);
            this.button6.TabIndex = 1;
            this.button6.Text = "Povratak na prijavu";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.Button6_Click);
            // 
            // dataGridView4
            // 
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Location = new System.Drawing.Point(3, 85);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(1521, 711);
            this.dataGridView4.TabIndex = 0;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.panel2);
            this.tabPage5.Controls.Add(this.button5);
            this.tabPage5.Controls.Add(this.dataGridView1);
            this.tabPage5.Controls.Add(this.button2);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(1527, 752);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "NOVI KORISNIK";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Controls.Add(this.button7);
            this.panel2.Controls.Add(this.textBox2);
            this.panel2.Controls.Add(this.textBox1);
            this.panel2.Controls.Add(this.textBox3);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.button1);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Location = new System.Drawing.Point(961, 142);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(428, 282);
            this.panel2.TabIndex = 12;
            // 
            // button7
            // 
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button7.Location = new System.Drawing.Point(318, 210);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(83, 42);
            this.button7.TabIndex = 8;
            this.button7.Text = "Poništi";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.Button7_Click);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox2.Location = new System.Drawing.Point(196, 72);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(205, 26);
            this.textBox2.TabIndex = 3;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox1.Location = new System.Drawing.Point(196, 22);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(205, 26);
            this.textBox1.TabIndex = 2;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox3.Location = new System.Drawing.Point(196, 122);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(205, 26);
            this.textBox3.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(57, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ime i prezime";
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(53, 210);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(149, 42);
            this.button1.TabIndex = 4;
            this.button1.Text = "Dodaj korisnika";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(81, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(71, 20);
            this.label3.TabIndex = 7;
            this.label3.Text = "Lozinka";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(49, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Korisničko ime";
            // 
            // button5
            // 
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button5.Location = new System.Drawing.Point(1316, 21);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(181, 42);
            this.button5.TabIndex = 11;
            this.button5.Text = "Povratak na prijavu";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.Button5_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(3, 85);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(815, 579);
            this.dataGridView1.TabIndex = 10;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button2.Location = new System.Drawing.Point(26, 682);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(181, 42);
            this.button2.TabIndex = 9;
            this.button2.Text = "Izbrisi korisnika";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // analizaDataSet8
            // 
            this.analizaDataSet8.DataSetName = "analizaDataSet8";
            this.analizaDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // osobaBindingSource
            // 
            this.osobaBindingSource.DataMember = "Osoba";
            this.osobaBindingSource.DataSource = this.analizaDataSet8;
            // 
            // osobaTableAdapter
            // 
            this.osobaTableAdapter.ClearBeforeFill = true;
            // 
            // analizaDataSet9
            // 
            this.analizaDataSet9.DataSetName = "analizaDataSet9";
            this.analizaDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // osobaBindingSource1
            // 
            this.osobaBindingSource1.DataMember = "Osoba";
            this.osobaBindingSource1.DataSource = this.analizaDataSet9;
            // 
            // osobaTableAdapter1
            // 
            this.osobaTableAdapter1.ClearBeforeFill = true;
            // 
            // analizaDataSet10
            // 
            this.analizaDataSet10.DataSetName = "analizaDataSet10";
            this.analizaDataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // osobaBindingSource2
            // 
            this.osobaBindingSource2.DataMember = "Osoba";
            this.osobaBindingSource2.DataSource = this.analizaDataSet10;
            // 
            // osobaTableAdapter2
            // 
            this.osobaTableAdapter2.ClearBeforeFill = true;
            // 
            // analizaDataSet11
            // 
            this.analizaDataSet11.DataSetName = "analizaDataSet11";
            this.analizaDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // osobaBindingSource3
            // 
            this.osobaBindingSource3.DataMember = "Osoba";
            this.osobaBindingSource3.DataSource = this.analizaDataSet11;
            // 
            // osobaTableAdapter3
            // 
            this.osobaTableAdapter3.ClearBeforeFill = true;
            // 
            // analizaDataSet12
            // 
            this.analizaDataSet12.DataSetName = "analizaDataSet12";
            this.analizaDataSet12.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // osobaBindingSource4
            // 
            this.osobaBindingSource4.DataMember = "Osoba";
            this.osobaBindingSource4.DataSource = this.analizaDataSet12;
            // 
            // osobaTableAdapter4
            // 
            this.osobaTableAdapter4.ClearBeforeFill = true;
            // 
            // analizaDataSet13
            // 
            this.analizaDataSet13.DataSetName = "analizaDataSet13";
            this.analizaDataSet13.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ablBindingSource
            // 
            this.ablBindingSource.DataMember = "Abl";
            this.ablBindingSource.DataSource = this.analizaDataSet13;
            // 
            // ablTableAdapter
            // 
            this.ablTableAdapter.ClearBeforeFill = true;
            // 
            // analizaDataSet18
            // 
            this.analizaDataSet18.DataSetName = "analizaDataSet18";
            this.analizaDataSet18.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // apsorcijaretencijaBindingSource
            // 
            this.apsorcijaretencijaBindingSource.DataMember = "Apsorcija_retencija";
            this.apsorcijaretencijaBindingSource.DataSource = this.analizaDataSet18;
            // 
            // apsorcija_retencijaTableAdapter
            // 
            this.apsorcija_retencijaTableAdapter.ClearBeforeFill = true;
            // 
            // analizaDataSet22
            // 
            this.analizaDataSet22.DataSetName = "analizaDataSet22";
            this.analizaDataSet22.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // analizaupijanjaravnaBindingSource
            // 
            this.analizaupijanjaravnaBindingSource.DataMember = "Analiza_upijanja_ravna";
            this.analizaupijanjaravnaBindingSource.DataSource = this.analizaDataSet22;
            // 
            // analiza_upijanja_ravnaTableAdapter
            // 
            this.analiza_upijanja_ravnaTableAdapter.ClearBeforeFill = true;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.panel3);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(1527, 752);
            this.tabPage4.TabIndex = 5;
            this.tabPage4.Text = "promjena targeta";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.button8);
            this.panel3.Controls.Add(this.textBox7);
            this.panel3.Controls.Add(this.comboBox2);
            this.panel3.Controls.Add(this.comboBox1);
            this.panel3.Location = new System.Drawing.Point(212, 86);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(508, 347);
            this.panel3.TabIndex = 0;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(49, 48);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 24);
            this.comboBox1.TabIndex = 0;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(49, 100);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(121, 24);
            this.comboBox2.TabIndex = 1;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(49, 177);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(121, 22);
            this.textBox7.TabIndex = 2;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(49, 249);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 3;
            this.button8.Text = "button8";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.Button8_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1535, 781);
            this.Controls.Add(this.panel1);
            this.Name = "Form3";
            this.Text = "Form3";
            this.Load += new System.EventHandler(this.Form3_Load);
            this.panel1.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.osobaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.osobaBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.osobaBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.osobaBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.osobaBindingSource4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ablBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.apsorcijaretencijaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaupijanjaravnaBindingSource)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private analizaDataSet8 analizaDataSet8;
        private System.Windows.Forms.BindingSource osobaBindingSource;
        private analizaDataSet8TableAdapters.OsobaTableAdapter osobaTableAdapter;
        private analizaDataSet9 analizaDataSet9;
        private System.Windows.Forms.BindingSource osobaBindingSource1;
        private analizaDataSet9TableAdapters.OsobaTableAdapter osobaTableAdapter1;
        private analizaDataSet10 analizaDataSet10;
        private System.Windows.Forms.BindingSource osobaBindingSource2;
        private analizaDataSet10TableAdapters.OsobaTableAdapter osobaTableAdapter2;
        private analizaDataSet11 analizaDataSet11;
        private System.Windows.Forms.BindingSource osobaBindingSource3;
        private analizaDataSet11TableAdapters.OsobaTableAdapter osobaTableAdapter3;
        private analizaDataSet12 analizaDataSet12;
        private System.Windows.Forms.BindingSource osobaBindingSource4;
        private analizaDataSet12TableAdapters.OsobaTableAdapter osobaTableAdapter4;
        private System.ComponentModel.BackgroundWorker backgroundWorker1;
        private analizaDataSet13 analizaDataSet13;
        private System.Windows.Forms.BindingSource ablBindingSource;
        private analizaDataSet13TableAdapters.AblTableAdapter ablTableAdapter;
        private analizaDataSet18 analizaDataSet18;
        private System.Windows.Forms.BindingSource apsorcijaretencijaBindingSource;
        private analizaDataSet18TableAdapters.Apsorcija_retencijaTableAdapter apsorcija_retencijaTableAdapter;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private analizaDataSet22 analizaDataSet22;
        private System.Windows.Forms.BindingSource analizaupijanjaravnaBindingSource;
        private analizaDataSet22TableAdapters.Analiza_upijanja_ravnaTableAdapter analiza_upijanja_ravnaTableAdapter;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}