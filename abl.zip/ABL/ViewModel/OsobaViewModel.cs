﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABL.ViewModel
{
    public class OsobaViewModel
    {
        public int Id{ get; set; }

        public string Ime_prezime { get; set; }
        public string Korisnicko_ime { get; set; }
        public string Lozinka { get; set; }

    }
}
