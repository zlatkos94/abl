﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABL.ViewModel
{
    public class AblViewModel
    {
        public int Id_abl { get; set; }
        public DateTime Datum { get; set; }

        public String Ime_osobe { get; set; }
        public String Velicina { get; set; }
        public String Polozaj { get; set; }
        public String Proizvod { get; set; }


        public string Masa { get; set; }
       
        public string Masa_nakon_curenja { get; set; }
        public String Masa_upijene { get; set; }
        public string Stupanj_zastite { get; set; }

        public String Min_stupanj_zastite { get; set; }

        public string Komentar { get; set; }



    }
}
