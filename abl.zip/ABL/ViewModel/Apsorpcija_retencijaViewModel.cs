﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABL.ViewModel
{
    public class Apsorpcija_retencijaViewModel
    {
        public int Id { get; set; }
        public DateTime Datum { get; set; }

        public String Ime_osobe { get; set; }
        public String Velicina { get; set; }
        public String Proizvod { get; set; }
        public String Polozaj { get; set; }
      


        public string Masa_suhe_pelene { get; set; }

        public string Masa_nakon_cijeđenja { get; set; }
        public String Apsorpcija { get; set; }
        public string Min_apsorpcija { get; set; }

        public String Max_apsorpcija { get; set; }
        public String Masa_nakon_centrifugiranja { get; set; }
        public string Retencija { get; set; }

        public String Min_retencija { get; set; }
        public String Max_retencija { get; set; }


        public string Komentar { get; set; }
    }
}
