﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ABL.ViewModel
{
    class RavnaViewModel
    {
        public int Id_ravna { get; set; }
        public DateTime Datum { get; set; }
        public string Velicina { get; set; }
        public string Proizvod { get; set; }
        public string Korisnik { get; set; }
        public string Masa { get; set; }
        public string PrvoUpijanje { get; set; }
        public string DrugoUpijanje { get; set; }
        public string TreceUpijanje { get; set; }
        public string CetvrtoUpijanje { get; set; }
        public string Povrat { get; set; }
        public string Komentar { get; set; }
    }
}
