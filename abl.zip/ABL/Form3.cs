﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ABL.Models;


namespace ABL
{
    public partial class Form3 : Form
    {
        string trazenje = "";

        private readonly analizaContext baza = new analizaContext();

        public Form3()
        {
            InitializeComponent();
            popuniOsobe();
            popuniAbl();
            popuniApsorpcijaRetencija();
            popuniRavnu();
            dataGridView2.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView3.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView4.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            this.WindowState = FormWindowState.Maximized;



        }

        private void popuniOsobe()
        {
            using (analizaContext ctx = new analizaContext())


            {
                var osobe = new BindingList<ViewModel.OsobaViewModel>((from o in ctx.Osoba

                                                            
                                                             where o.Status == false && o.KorisnickoIme != "admin"

                                                                       select new ViewModel.OsobaViewModel()
                                                             {
                                                                Id=o.IdOsoba,
                                                                Ime_prezime=o.Ime_prezime,
                                                                Korisnicko_ime=o.KorisnickoIme,
                                                                Lozinka=o.Lozinka
                                                             }).ToList());

                
                dataGridView1.DataSource = osobe;
                dataGridView1.Refresh();
                for (int i = 0; i < dataGridView1.Columns.Count; i++)
                {
                    this.dataGridView1.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                    this.dataGridView1.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                    this.dataGridView1.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                }
       
            }
        }

        private void popuniAbl()
        {
            using (analizaContext ctx = new analizaContext())


            {
                var abl = new BindingList<ViewModel.AblViewModel>((from a in ctx.Abl
                                                                   join o in ctx.Osoba on a.FkOsoba equals o.IdOsoba
                                                                   join v in ctx.Velicina on a.FkVelicina equals v.IdVelicine
                                                                   join po in ctx.Lutka on a.FkPolozaj equals po.IdLutke
                                                                   join pr in ctx.Proizvod on a.FkProizvod equals pr.IdProizvoda

                                                                   select new ViewModel.AblViewModel()
                                                                   {
                                                                       Id_abl = a.IdAbl,
                                                                       Datum = a.Datum,
                                                                       Ime_osobe = o.Ime_prezime,
                                                                       Velicina = v.Velicina1,
                                                                       Polozaj = po.PolozajLutke,
                                                                       Proizvod = pr.Proizvod1,
                                                                       Masa = a.Masa,
                                                                       Masa_nakon_curenja = a.MasaNakonCurenja,
                                                                       Masa_upijene = a.MasaUpijene,
                                                                       Stupanj_zastite = a.StupanjZastite,
                                                                       Min_stupanj_zastite = a.MinStupanjZastite,
                                                                       Komentar = a.Komentar,

                                                                   }).ToList());

                dataGridView2.DataSource = abl;
                dataGridView2.Refresh();
                for (int i = 0; i < dataGridView2.Columns.Count; i++)
                {
                    dataGridView2.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                    this.dataGridView2.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                    this.dataGridView2.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                }
            }
        }


        private void popuniRavnu()
        {
            using (analizaContext ctx = new analizaContext())


            {
                var ravna = new BindingList<ViewModel.RavnaViewModel>((from aur in ctx.AnalizaUpijanjaRavna
                                                                   join o in ctx.Osoba on aur.FkKorisnik equals o.IdOsoba
                                                                   join v in ctx.Velicina on aur.FkKorisnik equals v.IdVelicine
                                                                   join pr in ctx.Proizvod on aur.FkProizvod equals pr.IdProizvoda

                                                                   select new ViewModel.RavnaViewModel()
                                                                   {
                                                                       Id_ravna = aur.IdAnalizaUpijanjaRavna,
                                                                       Datum = aur.Datum,
                                                                       Korisnik = o.Ime_prezime,
                                                                       Velicina = v.Velicina1,
                                                                       Proizvod = pr.Proizvod1,
                                                                       Masa = aur.Masa,
                                                                       PrvoUpijanje = aur.PrvoUpijanje,
                                                                       DrugoUpijanje = aur.DrugoUpijanje,
                                                                       TreceUpijanje = aur.TreceUpijanje,
                                                                       CetvrtoUpijanje = aur.CetvrtoUpijanje,
                                                                       Povrat= aur.Povrat,
                                                                       Komentar = aur.Komentar,

                                                                   }).ToList());

                dataGridView4.DataSource = ravna;
                dataGridView4.Refresh();
                for (int i = 0; i < dataGridView4.Columns.Count; i++)
                {

                    dataGridView4.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                    this.dataGridView4.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                    this.dataGridView4.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                }
            }
        }

        private void popuniApsorpcijaRetencija()
        {
            using (analizaContext ctx = new analizaContext())


            {
                var ar = new BindingList<ViewModel.Apsorpcija_retencijaViewModel>((from a in ctx.ApsorcijaRetencija
                                                                                   join o in ctx.Osoba on a.FkKorisnik equals o.IdOsoba
                                                                                   join v in ctx.Velicina on a.FkVelicina equals v.IdVelicine
                                                                                   join po in ctx.Lutka on a.FkLutka equals po.IdLutke
                                                                                   join pr in ctx.Proizvod on a.FkProizvod equals pr.IdProizvoda

                                                                                   select new ViewModel.Apsorpcija_retencijaViewModel()
                                                                                   {
                                                                                       Id = a.IdApsorpcijaRetencija,
                                                                                       Datum = a.Datum,
                                                                                       Ime_osobe = o.Ime_prezime,
                                                                                       Velicina = v.Velicina1,
                                                                                       Polozaj = po.PolozajLutke,
                                                                                       Proizvod = pr.Proizvod1,
                                                                                       Masa_suhe_pelene = a.MasaSuhePelene,
                                                                                       Masa_nakon_cijeđenja=a.MasaNakonCijedjenja,
                                                                                       Apsorpcija=a.Apsorpcija,
                                                                                       Min_apsorpcija=a.MinApsorpcija,
                                                                                       Max_apsorpcija=a.MaxApsorpcija,
                                                                                       Masa_nakon_centrifugiranja=a.MasaNakonCentrifugiranja,
                                                                                       Retencija=a.Retencija,
                                                                                       Min_retencija=a.MinRetencija,
                                                                                       Max_retencija=a.MaxRetencija,
                                                                                        Komentar = a.Komentar,

                                                                                   }).ToList());
               
                dataGridView3.DataSource = ar;
                dataGridView3.Refresh();
                for (int i = 0; i < dataGridView3.Columns.Count; i++)
                {
                    dataGridView3.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                    this.dataGridView3.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.DisplayedCells;
                    this.dataGridView3.Columns[i].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                }
            }
        }



        private void Button1_Click(object sender, EventArgs e)
        {
            using (var ctx = new analizaContext())
            {
                if (!String.IsNullOrEmpty(textBox1.Text) && !String.IsNullOrEmpty(textBox3.Text) && !String.IsNullOrEmpty(textBox2.Text))
                { 

                    Osoba o = new Osoba();

                o.Ime_prezime = textBox1.Text;
                o.KorisnickoIme = textBox2.Text;
                o.Lozinka = textBox3.Text;
             
                


                ctx.Osoba.Add(o);
                ctx.SaveChanges();
                popuniOsobe();
                dataGridView1.Refresh();
                textBox1.Text = "";
                textBox2.Text = "";

                textBox3.Text = "";

            }
                else { MessageBox.Show("Molimo unesite sva polja");}
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'analizaDataSet22.Analiza_upijanja_ravna' table. You can move, or remove it, as needed.
            this.analiza_upijanja_ravnaTableAdapter.Fill(this.analizaDataSet22.Analiza_upijanja_ravna);
            // TODO: This line of code loads data into the 'analizaDataSet18.Apsorcija_retencija' table. You can move, or remove it, as needed.
            this.apsorcija_retencijaTableAdapter.Fill(this.analizaDataSet18.Apsorcija_retencija);
            // TODO: This line of code loads data into the 'analizaDataSet13.Abl' table. You can move, or remove it, as needed.
            this.ablTableAdapter.Fill(this.analizaDataSet13.Abl);
            // TODO: This line of code loads data into the 'analizaDataSet12.Osoba' table. You can move, or remove it, as needed.
            this.osobaTableAdapter4.Fill(this.analizaDataSet12.Osoba);
            // TODO: This line of code loads data into the 'analizaDataSet11.Osoba' table. You can move, or remove it, as needed.
            this.osobaTableAdapter3.Fill(this.analizaDataSet11.Osoba);
            // TODO: This line of code loads data into the 'analizaDataSet10.Osoba' table. You can move, or remove it, as needed.
            this.osobaTableAdapter2.Fill(this.analizaDataSet10.Osoba);
            // TODO: This line of code loads data into the 'analizaDataSet9.Osoba' table. You can move, or remove it, as needed.
            this.osobaTableAdapter1.Fill(this.analizaDataSet9.Osoba);
            // TODO: This line of code loads data into the 'analizaDataSet8.Osoba' table. You can move, or remove it, as needed.
            this.osobaTableAdapter.Fill(this.analizaDataSet8.Osoba);

        }

        private void Button2_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Jeste li sigurni da želite ukloniti korisnika.", "Potvrda Unosa", MessageBoxButtons.YesNo,
             MessageBoxIcon.Information);

            if (dr == DialogResult.No)
            {
                return;
            }

            int br = 0;
            var osoba = baza.Osoba.Where(a => a.IdOsoba == Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value)).FirstOrDefault();
            osoba.Status = true;
            
            baza.Osoba.Update(osoba);
            baza.SaveChanges();

            popuniOsobe();

            dataGridView1.Update();

            dataGridView1.Refresh();
        }

        public void prikazi()
        {

            using (analizaContext ctx = new analizaContext())


            {
                var abl = new BindingList<ViewModel.AblViewModel>((from a in ctx.Abl
                                                                   join o in ctx.Osoba on a.FkOsoba equals o.IdOsoba
                                                                   join v in ctx.Velicina on a.FkVelicina equals v.IdVelicine
                                                                   join po in ctx.Lutka on a.FkPolozaj equals po.IdLutke
                                                                   join pr in ctx.Proizvod on a.FkProizvod equals pr.IdProizvoda

                                                                   select new ViewModel.AblViewModel()
                                                                   {
                                                                       Id_abl = a.IdAbl,
                                                                       Datum = a.Datum,

                                                                       Ime_osobe = o.Ime_prezime,
                                                                       Velicina = v.Velicina1,
                                                                       Polozaj = po.PolozajLutke,
                                                                       Proizvod = pr.Proizvod1,
                                                                       Masa = a.Masa,
                                                                       Masa_nakon_curenja = a.MasaNakonCurenja,
                                                                       Masa_upijene = a.MasaUpijene,
                                                                       Stupanj_zastite = a.StupanjZastite,
                                                                       Min_stupanj_zastite = a.MinStupanjZastite,
                                                                       Komentar = a.Komentar,
                                                                       

                                                                   }).Where(n => n.Ime_osobe.ToLower().Contains(trazenje.ToLower())).OrderByDescending(o => o.Datum).ToList());

                dataGridView2.DataSource = abl;
                dataGridView2.Refresh();
            }


        }

        private void TextBox4_TextChanged(object sender, EventArgs e)
        {
            trazenje = textBox4.Text;
            prikazi();
        }
        public void prikazi1()
        {

            using (analizaContext ctx = new analizaContext())


            {
                var ar = new BindingList<ViewModel.Apsorpcija_retencijaViewModel>((from a in ctx.ApsorcijaRetencija
                                                                                    join o in ctx.Osoba on a.FkKorisnik equals o.IdOsoba
                                                                                    join v in ctx.Velicina on a.FkVelicina equals v.IdVelicine
                                                                                    join po in ctx.Lutka on a.FkLutka equals po.IdLutke
                                                                                    join pr in ctx.Proizvod on a.FkProizvod equals pr.IdProizvoda

                                                                                    select new ViewModel.Apsorpcija_retencijaViewModel()
                                                                                    {
                                                                                        Id = a.IdApsorpcijaRetencija,
                                                                                        Datum = a.Datum,
                                                                                        Ime_osobe = o.Ime_prezime,
                                                                                        Velicina = v.Velicina1,
                                                                                        Polozaj = po.PolozajLutke,
                                                                                        Proizvod = pr.Proizvod1,
                                                                                        Masa_suhe_pelene = a.MasaSuhePelene,
                                                                                        Masa_nakon_cijeđenja = a.MasaNakonCijedjenja,
                                                                                        Apsorpcija = a.Apsorpcija,
                                                                                        Min_apsorpcija = a.MinApsorpcija,
                                                                                        Max_apsorpcija = a.MaxApsorpcija,
                                                                                        Masa_nakon_centrifugiranja = a.MasaNakonCentrifugiranja,
                                                                                        Retencija = a.Retencija,
                                                                                        Min_retencija = a.MinRetencija,
                                                                                        Max_retencija = a.MaxRetencija,
                                                                                        Komentar = a.Komentar,


                                                                                    }).Where(n => n.Ime_osobe.ToLower().Contains(trazenje.ToLower())).OrderByDescending(o => o.Datum).ToList());

                dataGridView3.DataSource = ar;
                dataGridView3.Refresh();
            }


        }

        private void TextBox5_TextChanged(object sender, EventArgs e)
        {
            trazenje = textBox5.Text;
            prikazi1();
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }

        private void DataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }

        private void Button7_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";

            textBox3.Text = "";
        }

        private void Button8_Click(object sender, EventArgs e)
        {
            using (var ctx = new analizaContext())
            {

               
            }
        }
    }
}
