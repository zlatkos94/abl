﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ABL.Models;
using ABL.ViewModel;

namespace ABL
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();

            textBox2.Text = DateTime.Now.ToString();
            id();
            padajuca();
            this.WindowState = FormWindowState.Maximized;

        }



        private void TextBox1_TextChanged(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(textBox1.Text) && !String.IsNullOrEmpty(textBox3.Text))
            {

                if (Convert.ToDouble(textBox1.Text) > Convert.ToDouble(textBox3.Text))
                {
                    MessageBox.Show("Unijeli ste nedozvoljene vrijednosti");
                }
            }
        }



        

        private void Button2_Click(object sender, EventArgs e)
        {
            ClearTextBoxes();
            textBox2.Text = DateTime.Now.ToString();
            textBox1.Text = "(Novi)";

            richTextBox1.Text = null;
            comboBox1.ResetText();
            comboBox2.ResetText();
            comboBox3.ResetText();
            comboBox4.ResetText();

            id();

        }

      


        private void ClearTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Clear();
                    else
                        func(control.Controls);
            };

            func(Controls);
        }

        private void TextBox6_TextChanged(object sender, EventArgs e)
        {

            string rez = textBox6.Text;
            if (!String.IsNullOrEmpty(textBox5.Text) && !String.IsNullOrEmpty(textBox6.Text))
            {
                textBox12.Text = (Convert.ToDouble(textBox5.Text) - Convert.ToDouble(textBox6.Text)).ToString();
            }

        }

        private void zabrana(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != ','))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf(',') > -1))
            {
                e.Handled = true;
            }
        }


        private void TextBox5_TextChanged(object sender, EventArgs e)
        {




            if (!String.IsNullOrEmpty(textBox5.Text) && !String.IsNullOrEmpty(textBox6.Text))
            {
                textBox12.Text = (Convert.ToDouble(textBox5.Text) - Convert.ToDouble(textBox6.Text)).ToString();
            }


            if (!String.IsNullOrEmpty(textBox12.Text) && !String.IsNullOrEmpty(textBox6.Text) && !String.IsNullOrEmpty(textBox5.Text))
            {

                textBox11.Text = ((Convert.ToDouble(textBox12.Text) / Convert.ToDouble(textBox5.Text) * 100).ToString());

                label10.Visible = true;

            }





        }



        private void TextBox12_TextChanged(object sender, EventArgs e)
        {
            textBox12.ReadOnly = true;
            if (!String.IsNullOrEmpty(textBox12.Text) && !String.IsNullOrEmpty(textBox6.Text) && !String.IsNullOrEmpty(textBox5.Text))
            {
                double value;
                value = ((Convert.ToDouble(textBox12.Text) / Convert.ToDouble(textBox5.Text) * 100));
                value = Math.Round(value, 2);
                textBox11.Text = value.ToString();


                //textBox11.Text = ((Convert.ToDouble(textBox12.Text) / Convert.ToDouble(textBox5.Text) * 100).ToString());
                label10.Visible = true;

            }


        }




        private void TextBox11_TextChanged(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(textBox12.Text) && !String.IsNullOrEmpty(textBox6.Text) && !String.IsNullOrEmpty(textBox5.Text))
            {

                double value;
                value = ((Convert.ToDouble(textBox12.Text) / Convert.ToDouble(textBox5.Text) * 100));
                value = Math.Round(value, 2);
                textBox11.Text = value.ToString();
                label10.Visible = true;

            }

            if (!String.IsNullOrEmpty(textBox11.Text) && !String.IsNullOrEmpty(textBox3.Text) )
            {

                if (Convert.ToDouble(textBox11.Text) >= Convert.ToDouble(textBox3.Text))
                { textBox11.ForeColor = Color.BlueViolet; }
                else { textBox11.ForeColor = Color.Red; }

            }






        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'analizaDataSet23.Osoba' table. You can move, or remove it, as needed.
            this.osobaTableAdapter3.Fill(this.analizaDataSet23.Osoba);
            // TODO: This line of code loads data into the 'analizaDataSet7.Velicina' table. You can move, or remove it, as needed.
            this.velicinaTableAdapter2.Fill(this.analizaDataSet7.Velicina);
            // TODO: This line of code loads data into the 'analizaDataSet6.Velicina' table. You can move, or remove it, as needed.
            this.velicinaTableAdapter1.Fill(this.analizaDataSet6.Velicina);
            // TODO: This line of code loads data into the 'analizaDataSet5.Osoba' table. You can move, or remove it, as needed.
            this.osobaTableAdapter2.Fill(this.analizaDataSet5.Osoba);
            // TODO: This line of code loads data into the 'analizaDataSet4.Lutka' table. You can move, or remove it, as needed.
            this.lutkaTableAdapter.Fill(this.analizaDataSet4.Lutka);
            // TODO: This line of code loads data into the 'analizaDataSet3.Proizvod' table. You can move, or remove it, as needed.
            this.proizvodTableAdapter.Fill(this.analizaDataSet3.Proizvod);
            // TODO: This line of code loads data into the 'analizaDataSet2.Velicina' table. You can move, or remove it, as needed.
            this.velicinaTableAdapter.Fill(this.analizaDataSet2.Velicina);
            // TODO: This line of code loads data into the 'analizaDataSet1.Osoba' table. You can move, or remove it, as needed.
            this.osobaTableAdapter1.Fill(this.analizaDataSet1.Osoba);

        }
        private void ComboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            textBox7.Text = comboBox1.Text;
            if (!String.IsNullOrEmpty(textBox7.Text) && !String.IsNullOrEmpty(textBox8.Text))
            {
                textBox3.Text = "82 ";
            }


        }


        private void ComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox8.Text = comboBox2.Text;
            if (!String.IsNullOrEmpty(textBox7.Text) && !String.IsNullOrEmpty(textBox8.Text))
            {
                textBox3.Text = "82 ";
            }


        }


        private void Button1_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Jeste li sigurni da želite spremiti zapis.", "Potvrdi", MessageBoxButtons.YesNo,
            MessageBoxIcon.Information);

            if (dr == DialogResult.No)
            {
                return;
            }

            if (textBox6.Text=="" || textBox5.Text == "" || textBox12.Text == "" || textBox3.Text=="")
            {
                MessageBox.Show("Molimo unesite sva polja i odaberite stavke");
                return;
            }

            


            if ((Convert.ToDouble(textBox3.Text) < Convert.ToDouble(textBox11.Text)) && (Convert.ToDouble(textBox11.Text)) < 101 )
            {
                MessageBox.Show("Stupanj zaštite se nalazi u odgovarajućim intervalima ");
                MessageBox.Show("Uspješno ste spremili analizu");
                textBox11.Clear();
            }

            if (Convert.ToDouble(textBox11.Text) < 72)
            {
                MessageBox.Show("Zaštita je manja od minimalne granice 72%");
                MessageBox.Show("Uspješno ste spremili analizu");


            }
            if ((Convert.ToDouble(textBox11.Text) > 72) && (Convert.ToDouble(textBox11.Text) < 82))
            { MessageBox.Show("Zaštita je između 72% i 82%");
                MessageBox.Show("Uspješno ste spremili analizu");
            }




            if (textBox2.Text == "")
            { MessageBox.Show("Unesite sva polja"); }
            else
            {
                {
                    using (var ctx = new analizaContext())
                    {

                        Abl a = new Abl();
                        DateTime da = DateTime.Now;
                        a.Datum = da;

                        DataRowView FkVelicina = comboBox1.SelectedItem as DataRowView;
                        int vfk = Convert.ToInt32(FkVelicina.Row.ItemArray[0]);
                        a.FkVelicina = vfk;

                        DataRowView FkProizvod = comboBox2.SelectedItem as DataRowView;
                        int pro = Convert.ToInt32(FkProizvod.Row.ItemArray[0]);
                        a.FkProizvod = pro;

                        DataRowView FkPolozaj = comboBox3.SelectedItem as DataRowView;
                        int pol = Convert.ToInt32(FkPolozaj.Row.ItemArray[0]);
                        a.FkPolozaj = pol;

                        //DataRowView FkOsoba = comboBox4.SelectedItem as DataRowView;
                        //int oso = Convert.ToInt32(FkOsoba.Row.ItemArray[0]);
                        //a.FkOsoba = oso;

                        a.FkOsoba = comboBox4.SelectedIndex;
                        a.MasaNakonCurenja = textBox5.Text;
                        a.MasaUpijene = textBox12.Text;
                        a.StupanjZastite = textBox11.Text;
                        a.Masa = textBox6.Text;
                        a.Komentar = richTextBox1.Text;
                        a.MinStupanjZastite = textBox3.Text;


                        ctx.Abl.Add(a);
                        ctx.SaveChanges();
                        ClearTextBoxes();
                        textBox2.Text = DateTime.Now.ToString();
                        textBox1.Text = "(Novi)";

                        richTextBox1.Text = null;
                        comboBox1.ResetText();
                        comboBox2.ResetText();
                        comboBox3.ResetText();
                        comboBox4.ResetText();
                        this.Hide();
                        Form5 f5 = new Form5();
                        f5.ShowDialog();
                    }
                }
            }
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }

        private void Button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form5 f5 = new Form5();
            f5.ShowDialog();
        }

        public void padajuca()

        {
            using (analizaContext ctx = new analizaContext())


            {
                {
                    var popuni = new List<ViewModel.OsobaViewModel>((from o in ctx.Osoba
                                                                     where o.Status == false && o.KorisnickoIme != "admin"

                                                                     select new ViewModel.OsobaViewModel()
                                                                     {
                                                                         Ime_prezime = o.Ime_prezime,
                                                                         Id = o.IdOsoba,
                                                                         Lozinka = o.Lozinka,
                                                                         Korisnicko_ime = o.KorisnickoIme

                                                                     }).ToList());

                    comboBox4.DataSource = popuni;
                    comboBox4.DisplayMember = "ime_prezime";
                    comboBox4.ValueMember = "Id";
                }
            }
        }


        public void id()

        {
            using (analizaContext ctx = new analizaContext())


            {
                {
                    var id = (from a in ctx.Abl
                              orderby a.IdAbl descending
                              select a.IdAbl).First();
                    id++;
                    textBox1.Text = id.ToString(); ;


                }
            }
        }

        private void ComboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
        }

        private void TextBox3_TextChanged(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(textBox11.Text) && !String.IsNullOrEmpty(textBox3.Text))
            {

                if (Convert.ToDouble(textBox11.Text) >= Convert.ToDouble(textBox3.Text))
                { textBox11.ForeColor = Color.Green; }
                else { textBox11.ForeColor = Color.Red; }

            }
        }
    }
}



              