﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ABL.Models;


namespace ABL
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
            textBox2.Text = DateTime.Now.ToString();
            this.WindowState = FormWindowState.Maximized;
            id();
        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'analizaDataSet17.Osoba' table. You can move, or remove it, as needed.
            this.osobaTableAdapter3.Fill(this.analizaDataSet17.Osoba);
            // TODO: This line of code loads data into the 'analizaDataSet16.Lutka' table. You can move, or remove it, as needed.
            this.lutkaTableAdapter1.Fill(this.analizaDataSet16.Lutka);
            // TODO: This line of code loads data into the 'analizaDataSet15.Proizvod' table. You can move, or remove it, as needed.
            this.proizvodTableAdapter1.Fill(this.analizaDataSet15.Proizvod);
            // TODO: This line of code loads data into the 'analizaDataSet14.Velicina' table. You can move, or remove it, as needed.
            this.velicinaTableAdapter3.Fill(this.analizaDataSet14.Velicina);

        }

        public void id()

        {
            using (analizaContext ctx = new analizaContext())


            {
                {
                    var id = (from a in ctx.ApsorcijaRetencija
                              orderby a.IdApsorpcijaRetencija descending
                              select a.IdApsorpcijaRetencija).First();
                    id++;
                    textBox1.Text = id.ToString(); ;


                }
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            ClearTextBoxes();
            richTextBox1.Text = null;
            comboBox1.ResetText();
            comboBox2.ResetText();
            comboBox3.ResetText();
            comboBox4.ResetText();
            id();
            textBox2.Text = DateTime.Now.ToString();

        }
        private void ClearTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Clear();
                    else
                        func(control.Controls);
            };

            func(Controls);
        }

        private void ComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox8.Text = comboBox2.Text;
            if (!String.IsNullOrEmpty(textBox7.Text) && !String.IsNullOrEmpty(textBox8.Text))
            {
                if (comboBox1.SelectedIndex == 0 && comboBox2.SelectedIndex == 0)
                {
                    textBox15.Text = "20,5";
                    textBox3.Text = "23,3";
                    textBox19.Text = "320";
                    textBox18.Text = "410";
                    textBox17.Text = "205";
                    textBox16.Text = "260";

                }
                if (comboBox1.SelectedIndex == 1 && comboBox2.SelectedIndex == 0)
                {
                    textBox15.Text = "22,1";
                    textBox3.Text = "24,9";
                    textBox19.Text = "330";
                    textBox18.Text = "430";
                    textBox17.Text = "215";
                    textBox16.Text = "265";
                }
                if (comboBox1.SelectedIndex == 2 && comboBox2.SelectedIndex == 0)
                {
                    textBox15.Text = "27,7";
                    textBox3.Text = "30,5";
                    textBox19.Text = "410";
                    textBox18.Text = "510";
                    textBox17.Text = "270";
                    textBox16.Text = "320";
                }
                if (comboBox1.SelectedIndex == 3 && comboBox2.SelectedIndex == 0)
                {
                    textBox15.Text = "36";
                    textBox3.Text = "38,8";
                    textBox19.Text = "560";
                    textBox18.Text = "660";
                    textBox17.Text = "365";
                    textBox16.Text = "430";
                }

                if (comboBox1.SelectedIndex == 4 && comboBox2.SelectedIndex == 0)
                {
                    textBox15.Text = "36";
                    textBox3.Text = "38,8";
                    textBox19.Text = "560";
                    textBox18.Text = "660";
                    textBox17.Text = "365";
                    textBox16.Text = "430";
                }
                if (comboBox1.SelectedIndex == 5 && comboBox2.SelectedIndex == 0)
                {
                    textBox15.Text = "40";
                    textBox3.Text = "42,8";
                    textBox19.Text = "635";
                    textBox18.Text = "735";
                    textBox17.Text = "420";
                    textBox16.Text = "480";
                }
                if (comboBox1.SelectedIndex == 6 && comboBox2.SelectedIndex == 0)
                {
                    textBox15.Text = "44,5";
                    textBox3.Text = "47,3";
                    textBox19.Text = "710";
                    textBox18.Text = "810";
                    textBox17.Text = "465";
                    textBox16.Text = "530";
                }


                if (comboBox1.SelectedIndex == 0 && comboBox2.SelectedIndex == 1)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";

                }
                if (comboBox1.SelectedIndex == 1 && comboBox2.SelectedIndex == 1)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
                if (comboBox1.SelectedIndex == 2 && comboBox2.SelectedIndex == 1)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
                if (comboBox1.SelectedIndex == 3 && comboBox2.SelectedIndex == 1)
                {
                    textBox15.Text = "31,1";
                    textBox3.Text = "33,9";
                    textBox19.Text = "535";
                    textBox18.Text = "635";
                    textBox17.Text = "370";
                    textBox16.Text = "430";
                }

                if (comboBox1.SelectedIndex == 4 && comboBox2.SelectedIndex == 1)
                {
                    textBox15.Text = "31,1";
                    textBox3.Text = "33,9";
                    textBox19.Text = "535";
                    textBox18.Text = "635";
                    textBox17.Text = "370";
                    textBox16.Text = "430";
                }
                if (comboBox1.SelectedIndex == 5 && comboBox2.SelectedIndex == 1)
                {
                    textBox15.Text = "34";
                    textBox3.Text = "36,8";
                    textBox19.Text = "590";
                    textBox18.Text = "690";
                    textBox17.Text = "390";
                    textBox16.Text = "450";
                }
                if (comboBox1.SelectedIndex == 6 && comboBox2.SelectedIndex == 1)
                {
                    textBox15.Text = "37,6";
                    textBox3.Text = "40,4";
                    textBox19.Text = "670";
                    textBox18.Text = "770";
                    textBox17.Text = "460";
                    textBox16.Text = "520";
                }

                if (comboBox1.SelectedIndex == 0 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";

                }
                if (comboBox1.SelectedIndex == 1 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "19.2";
                    textBox3.Text = "22";
                    textBox19.Text = "265";
                    textBox18.Text = "410";
                    textBox17.Text = "200";
                    textBox16.Text = "230";
                }
                if (comboBox1.SelectedIndex == 2 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "24,4";
                    textBox3.Text = "27,2";
                    textBox19.Text = "355";
                    textBox18.Text = "510";
                    textBox17.Text = "255";
                    textBox16.Text = "285";
                }
                if (comboBox1.SelectedIndex == 3 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "30,4";
                    textBox3.Text = "33,2";
                    textBox19.Text = "505";
                    textBox18.Text = "675";
                    textBox17.Text = "350";
                    textBox16.Text = "395";
                }

                if (comboBox1.SelectedIndex == 4 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
                if (comboBox1.SelectedIndex == 5 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "34";
                    textBox3.Text = "36,8";
                    textBox19.Text = "545";
                    textBox18.Text = "730";
                    textBox17.Text = "400";
                    textBox16.Text = "450";
                }
                if (comboBox1.SelectedIndex == 6 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "37,6";
                    textBox3.Text = "40,4";
                    textBox19.Text = "620";
                    textBox18.Text = "815";
                    textBox17.Text = "430";
                    textBox16.Text = "485";
                }
                if (comboBox1.SelectedIndex == 0 && comboBox2.SelectedIndex == 3)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";

                }
                if (comboBox1.SelectedIndex == 1 && comboBox2.SelectedIndex == 3)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
                if (comboBox1.SelectedIndex == 2 && comboBox2.SelectedIndex == 3)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
                if (comboBox1.SelectedIndex == 3 && comboBox2.SelectedIndex == 3)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }

                if (comboBox1.SelectedIndex == 4 && comboBox2.SelectedIndex == 3)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
                if (comboBox1.SelectedIndex == 5 && comboBox2.SelectedIndex == 3)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
                if (comboBox1.SelectedIndex == 6 && comboBox2.SelectedIndex == 3)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }

                if (comboBox1.SelectedIndex == 0 && comboBox2.SelectedIndex == 4)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";

                }
                if (comboBox1.SelectedIndex == 1 && comboBox2.SelectedIndex == 4)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
                if (comboBox1.SelectedIndex == 2 && comboBox2.SelectedIndex == 4)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
                if (comboBox1.SelectedIndex == 3 && comboBox2.SelectedIndex == 4)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }

                if (comboBox1.SelectedIndex == 4 && comboBox2.SelectedIndex == 4)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
                if (comboBox1.SelectedIndex == 5 && comboBox2.SelectedIndex == 4)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
                if (comboBox1.SelectedIndex == 6 && comboBox2.SelectedIndex == 4)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
            }
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox7.Text = comboBox1.Text;
            if (!String.IsNullOrEmpty(textBox7.Text) && !String.IsNullOrEmpty(textBox8.Text))
            {
                if (comboBox1.SelectedIndex == 0 && comboBox2.SelectedIndex == 0)
                {
                    textBox15.Text = "20,5";
                    textBox3.Text = "23,3";
                    textBox19.Text = "320";
                    textBox18.Text = "410";
                    textBox17.Text = "205";
                    textBox16.Text = "260";

                }
                if (comboBox1.SelectedIndex == 1 && comboBox2.SelectedIndex == 0)
                {
                    textBox15.Text = "22,1";
                    textBox3.Text = "24,9";
                    textBox19.Text = "330";
                    textBox18.Text = "430";
                    textBox17.Text = "215";
                    textBox16.Text = "265";
                }
                if (comboBox1.SelectedIndex == 2 && comboBox2.SelectedIndex == 0)
                {
                    textBox15.Text = "27,7";
                    textBox3.Text = "30,5";
                    textBox19.Text = "410";
                    textBox18.Text = "510";
                    textBox17.Text = "270";
                    textBox16.Text = "320";
                }
                if (comboBox1.SelectedIndex == 3 && comboBox2.SelectedIndex == 0)
                {
                    textBox15.Text = "36";
                    textBox3.Text = "38,8";
                    textBox19.Text = "560";
                    textBox18.Text = "660";
                    textBox17.Text = "365";
                    textBox16.Text = "430";
                }
                if (comboBox1.SelectedIndex == 4 && comboBox2.SelectedIndex == 0)
                {
                    textBox15.Text = "36";
                    textBox3.Text = "38,8";
                    textBox19.Text = "560";
                    textBox18.Text = "660";
                    textBox17.Text = "365";
                    textBox16.Text = "430";
                }
                if (comboBox1.SelectedIndex == 5 && comboBox2.SelectedIndex == 0)
                {
                    textBox15.Text = "40";
                    textBox3.Text = "42,8";
                    textBox19.Text = "635";
                    textBox18.Text = "735";
                    textBox17.Text = "420";
                    textBox16.Text = "480";
                }
                if (comboBox1.SelectedIndex == 6 && comboBox2.SelectedIndex == 0)
                {
                    textBox15.Text = "44,5";
                    textBox3.Text = "47,3";
                    textBox19.Text = "710";
                    textBox18.Text = "810";
                    textBox17.Text = "465";
                    textBox16.Text = "530";
                }

                if (comboBox1.SelectedIndex == 0 && comboBox2.SelectedIndex == 1)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";

                }
                if (comboBox1.SelectedIndex == 1 && comboBox2.SelectedIndex == 1)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
                if (comboBox1.SelectedIndex == 2 && comboBox2.SelectedIndex == 1)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
                if (comboBox1.SelectedIndex == 3 && comboBox2.SelectedIndex == 1)
                {
                    textBox15.Text = "31,1";
                    textBox3.Text = "33,9";
                    textBox19.Text = "535";
                    textBox18.Text = "635";
                    textBox17.Text = "370";
                    textBox16.Text = "430";
                }

                if (comboBox1.SelectedIndex == 4 && comboBox2.SelectedIndex == 1)
                {
                    textBox15.Text = "31,1";
                    textBox3.Text = "33,9";
                    textBox19.Text = "535";
                    textBox18.Text = "635";
                    textBox17.Text = "370";
                    textBox16.Text = "430";
                }
                if (comboBox1.SelectedIndex == 5 && comboBox2.SelectedIndex == 1)
                {
                    textBox15.Text = "34";
                    textBox3.Text = "36,8";
                    textBox19.Text = "590";
                    textBox18.Text = "690";
                    textBox17.Text = "390";
                    textBox16.Text = "450";
                }
                if (comboBox1.SelectedIndex == 6 && comboBox2.SelectedIndex == 1)
                {
                    textBox15.Text = "37,6";
                    textBox3.Text = "40,4";
                    textBox19.Text = "670";
                    textBox18.Text = "770";
                    textBox17.Text = "460";
                    textBox16.Text = "520";
                }
                if (comboBox1.SelectedIndex == 0 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";

                }
                if (comboBox1.SelectedIndex == 1 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "19,2";
                    textBox3.Text = "22";
                    textBox19.Text = "265";
                    textBox18.Text = "410";
                    textBox17.Text = "200";
                    textBox16.Text = "230";
                }
                if (comboBox1.SelectedIndex == 2 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "24,4";
                    textBox3.Text = "27,2";
                    textBox19.Text = "355";
                    textBox18.Text = "510";
                    textBox17.Text = "255";
                    textBox16.Text = "285";
                }
                if (comboBox1.SelectedIndex == 3 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "30,4";
                    textBox3.Text = "33,2";
                    textBox19.Text = "505";
                    textBox18.Text = "675";
                    textBox17.Text = "350";
                    textBox16.Text = "395";
                }

                if (comboBox1.SelectedIndex == 4 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
                if (comboBox1.SelectedIndex == 5 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "34";
                    textBox3.Text = "36,8";
                    textBox19.Text = "545";
                    textBox18.Text = "730";
                    textBox17.Text = "400";
                    textBox16.Text = "450";
                }
                if (comboBox1.SelectedIndex == 6 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "37,6";
                    textBox3.Text = "40,4";
                    textBox19.Text = "620";
                    textBox18.Text = "815";
                    textBox17.Text = "430";
                    textBox16.Text = "485";
                }

                if (comboBox1.SelectedIndex == 0 && comboBox2.SelectedIndex == 3)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";

                }
                if (comboBox1.SelectedIndex == 1 && comboBox2.SelectedIndex == 3)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
                if (comboBox1.SelectedIndex == 2 && comboBox2.SelectedIndex == 3)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
                if (comboBox1.SelectedIndex == 3 && comboBox2.SelectedIndex == 3)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }

                if (comboBox1.SelectedIndex == 4 && comboBox2.SelectedIndex == 3)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
                if (comboBox1.SelectedIndex == 5 && comboBox2.SelectedIndex == 3)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
                if (comboBox1.SelectedIndex == 6 && comboBox2.SelectedIndex == 3)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }

                if (comboBox1.SelectedIndex == 0 && comboBox2.SelectedIndex == 4)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";

                }
                if (comboBox1.SelectedIndex == 1 && comboBox2.SelectedIndex == 4)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
                if (comboBox1.SelectedIndex == 2 && comboBox2.SelectedIndex == 4)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
                if (comboBox1.SelectedIndex == 3 && comboBox2.SelectedIndex == 4)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }

                if (comboBox1.SelectedIndex == 4 && comboBox2.SelectedIndex == 4)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
                if (comboBox1.SelectedIndex == 5 && comboBox2.SelectedIndex == 4)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
                if (comboBox1.SelectedIndex == 6 && comboBox2.SelectedIndex == 4)
                {
                    textBox15.Text = "0";
                    textBox3.Text = "0";
                    textBox19.Text = "0";
                    textBox18.Text = "0";
                    textBox17.Text = "0";
                    textBox16.Text = "0";
                }
            }
        }

        private void TextBox5_TextChanged(object sender, EventArgs e)
        {

           

            if (!String.IsNullOrEmpty(textBox5.Text) && !String.IsNullOrEmpty(textBox6.Text))
            {
                textBox12.Text = (Convert.ToDouble(textBox5.Text) - Convert.ToDouble(textBox6.Text)).ToString();
            }
        }

        private void TextBox6_TextChanged(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(textBox15.Text) && !String.IsNullOrEmpty(textBox6.Text) && !String.IsNullOrEmpty(textBox3.Text))
            {
                if ((Convert.ToDecimal(textBox6.Text) >= Convert.ToDecimal(textBox15.Text)) && (Convert.ToDecimal(textBox6.Text) <= Convert.ToDecimal(textBox3.Text)))
                { textBox6.ForeColor = Color.BlueViolet; }
                else { textBox6.ForeColor = Color.Red; }
            }



            if (!String.IsNullOrEmpty(textBox5.Text) && !String.IsNullOrEmpty(textBox6.Text))
            {
                textBox12.Text = (Convert.ToDouble(textBox5.Text) - Convert.ToDouble(textBox6.Text)).ToString();
            }
            if (!String.IsNullOrEmpty(textBox6.Text) && !String.IsNullOrEmpty(textBox10.Text))
            {
                textBox9.Text = (Convert.ToDouble(textBox10.Text) - Convert.ToDouble(textBox6.Text)).ToString();
            }

        }

        private void zabrana(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != ','))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf(',') > -1))
            {
                e.Handled = true;
            }
        }

        private void TextBox10_TextChanged(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(textBox6.Text) && !String.IsNullOrEmpty(textBox10.Text))
            {
                textBox9.Text = (Convert.ToDouble(textBox10.Text) - Convert.ToDouble(textBox6.Text)).ToString();
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Jeste li sigurni da želite spremiti zapis.", "Potvrdi", MessageBoxButtons.YesNo,
            MessageBoxIcon.Information);

            if (dr == DialogResult.No)
            {
                return;
            }

            if (textBox6.Text == "" || textBox5.Text == ""  || textBox10.Text == "" || textBox9.Text == ""|| textBox8.Text == "" || textBox7.Text == "")
            {
                MessageBox.Show("Molimo unesite sva polja i odaberite stavke");
                return;
            }

          
            using (var ctx = new analizaContext())
                    {

                        ApsorcijaRetencija a = new ApsorcijaRetencija();
                        DateTime da = DateTime.Now;
                        a.Datum = da;
                         

                        DataRowView FkVelicina = comboBox1.SelectedItem as DataRowView;
                        int vfk = Convert.ToInt32(FkVelicina.Row.ItemArray[0]);
                        a.FkVelicina = vfk;

                        DataRowView FkProizvod = comboBox2.SelectedItem as DataRowView;
                        int pro = Convert.ToInt32(FkProizvod.Row.ItemArray[0]);
                        a.FkProizvod = pro;

                DataRowView FkLutka = comboBox3.SelectedItem as DataRowView;
                int lut = Convert.ToInt32(FkLutka.Row.ItemArray[0]);
                a.FkLutka = lut;

        

                DataRowView FkKorisnik = comboBox4.SelectedItem as DataRowView;
                        int oso = Convert.ToInt32(FkKorisnik.Row.ItemArray[0]);
                        a.FkKorisnik = oso;


                        a.MasaSuhePelene = textBox6.Text;
                        a.MasaNakonCijedjenja = textBox5.Text;
                        a.Apsorpcija = textBox12.Text;
                        a.MasaNakonCentrifugiranja = textBox10.Text;
                        a.Retencija = textBox9.Text;
                        a.Komentar = richTextBox1.Text;


                ctx.ApsorcijaRetencija.Add(a);
                        ctx.SaveChanges();

                this.Hide();
                Form5 f5 = new Form5();
                f5.ShowDialog();
            }
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form5 f5 = new Form5();
            f5.ShowDialog();
        }

        private void TextBox12_TextChanged(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(textBox12.Text) && !String.IsNullOrEmpty(textBox19.Text) && !String.IsNullOrEmpty(textBox18.Text))
            {
                if ((Convert.ToDecimal(textBox12.Text) >= Convert.ToDecimal(textBox19.Text)) && (Convert.ToDecimal(textBox12.Text) <= Convert.ToDecimal(textBox18.Text)))
                { textBox12.ForeColor = Color.BlueViolet; }
                else { textBox12.ForeColor = Color.Red; }
            }
        }

        private void TextBox9_TextChanged(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(textBox9.Text) && !String.IsNullOrEmpty(textBox10.Text) && !String.IsNullOrEmpty(textBox6.Text) && !String.IsNullOrEmpty(textBox16.Text) && !String.IsNullOrEmpty(textBox17.Text))
            {
                if ((Convert.ToDecimal(textBox9.Text) >= Convert.ToDecimal(textBox17.Text)) && (Convert.ToDecimal(textBox9.Text) <= Convert.ToDecimal(textBox16.Text)))
                { textBox9.ForeColor = Color.BlueViolet; }
                else { textBox9.ForeColor = Color.Red; }
            }
        }
    }
    }


  //if (Convert.ToDouble(textBox12.Text) > Convert.ToDouble(textBox3.Text))
  //          {
  //              MessageBox.Show("uredu je ");

  //          }


    //if (!String.IsNullOrEmpty(textBox14.Text) && !String.IsNullOrEmpty(textBox19.Text))
    //        {
    //            if (Convert.ToDecimal(textBox14.Text) >= Convert.ToDecimal(textBox19.Text)) 
    //            { textBox14.ForeColor = Color.Green; }
    //            else { textBox14.ForeColor = Color.Red; }
    //        }