﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ABL.Models;
using ABL.ViewModel;



namespace ABL
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            using (var ctx = new analizaContext())
            {
                var log = from o in ctx.Osoba
                          where o.KorisnickoIme == textBox1.Text && o.Lozinka == textBox2.Text && o.KorisnickoIme=="admin" && o.Status == false
                          select o;
                        
                if (log.SingleOrDefault() != null)
                {

                    this.Hide();
                    Form3 f3 = new Form3();
                    f3.ShowDialog();

                }

                var ostali = from o in ctx.Osoba
                             where o.KorisnickoIme == textBox1.Text && o.Lozinka == textBox2.Text && o.KorisnickoIme != "admin" && o.Status == false
                          select o;

                if (ostali.SingleOrDefault() != null)
                {

                    this.Hide();
                    Form5 f5 = new Form5();
                    f5.ShowDialog();

                }
                else { label4.Visible = true; }
            }
            }

        private void TextBox1_TextChanged(object sender, EventArgs e)
        {
            label4.Visible = false;
        }
    }
    }



   