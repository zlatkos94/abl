﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ABL.Models;


namespace ABL
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
            textBox2.Text = DateTime.Now.ToString();
            this.WindowState = FormWindowState.Maximized;
            id();
        }

        private void Panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form6_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'analizaDataSet21.Osoba' table. You can move, or remove it, as needed.
            this.osobaTableAdapter.Fill(this.analizaDataSet21.Osoba);
            // TODO: This line of code loads data into the 'analizaDataSet20.Proizvod' table. You can move, or remove it, as needed.
            this.proizvodTableAdapter.Fill(this.analizaDataSet20.Proizvod);
            // TODO: This line of code loads data into the 'analizaDataSet19.Velicina' table. You can move, or remove it, as needed.
            this.velicinaTableAdapter.Fill(this.analizaDataSet19.Velicina);

        }

        private void Button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form5 f5 = new Form5();
            f5.ShowDialog();
        }


        public void id()

        {
            using (analizaContext ctx = new analizaContext())


            {
                {
                    var id = (from a in ctx.AnalizaUpijanjaRavna
                              orderby a.IdAnalizaUpijanjaRavna descending
                              select a.IdAnalizaUpijanjaRavna).First();
                    id++;
                    textBox1.Text = id.ToString(); ;

                    
                }
            }
        }







        private void Button2_Click(object sender, EventArgs e)
        {
            ClearTextBoxes();
            richTextBox1.Text = null;
            comboBox1.ResetText();
            comboBox2.ResetText();
            comboBox3.ResetText();
            textBox2.Text = DateTime.Now.ToString();
            id();
        }
        private void ClearTextBoxes()
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Clear();
                    else
                        func(control.Controls);
            };

            func(Controls);
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox10.Text = comboBox1.Text;
            if (!String.IsNullOrEmpty(textBox10.Text) && !String.IsNullOrEmpty(textBox9.Text))
            {
                if (comboBox1.SelectedIndex == 0 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "1";
                    textBox14.Text = "80";
                }
                if (comboBox1.SelectedIndex == 1 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "1";
                    textBox14.Text = "100";

                }
                if (comboBox1.SelectedIndex == 2 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "1,5";
                    textBox14.Text = "150";

                }
                if (comboBox1.SelectedIndex == 3 && comboBox2.SelectedIndex == 2)
                {
                    textBox11.Text = "0";
                    textBox12.Text = "0";
                    textBox13.Text = "0";
                    textBox14.Text = "0";
                    textBox15.Text = "0";

                }
                if (comboBox1.SelectedIndex == 4 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "1,5";
                    textBox14.Text = "150";
                }
                if (comboBox1.SelectedIndex == 5 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "1,5";
                    textBox14.Text = "150";
                }
                else
                {
                    textBox11.Text = "0";
                    textBox12.Text = "0";
                    textBox13.Text = "0";
                    textBox14.Text = "0";
                    textBox15.Text = "0";
                }
            }

        }
        private void ComboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            textBox9.Text = comboBox2.Text;
            if (!String.IsNullOrEmpty(textBox10.Text) && !String.IsNullOrEmpty(textBox9.Text))
            {
                if (comboBox1.SelectedIndex == 0 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "1";
                    textBox14.Text = "80";
                }
                if (comboBox1.SelectedIndex == 1 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "1";
                    textBox14.Text = "100";

                }
                if (comboBox1.SelectedIndex == 2 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "1,5";
                    textBox14.Text = "150";

                }
                if (comboBox1.SelectedIndex == 3 && comboBox2.SelectedIndex == 2)
                {
                    textBox11.Text = "0";
                    textBox12.Text = "0";
                    textBox13.Text = "0";
                    textBox14.Text = "0";
                    textBox15.Text = "0";

                }
                if (comboBox1.SelectedIndex == 4 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "1,5";
                    textBox14.Text = "150";
                }
                if (comboBox1.SelectedIndex == 5 && comboBox2.SelectedIndex == 2)
                {
                    textBox15.Text = "1,5";
                    textBox14.Text = "150";
                }
            }
        }


        private void zabrana(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) &&
                (e.KeyChar != ','))
            {
                e.Handled = true;
            }

            // only allow one decimal point
            if ((e.KeyChar == ',') && ((sender as TextBox).Text.IndexOf(',') > -1))
            {
                e.Handled = true;
            }
        }
        private void Button1_Click(object sender, EventArgs e)
        {
            using (var ctx = new analizaContext())
            {

                AnalizaUpijanjaRavna a = new AnalizaUpijanjaRavna();
                DateTime da = DateTime.Now;
                a.Datum = da;

                DataRowView FkVelicina = comboBox1.SelectedItem as DataRowView;
                int vfk = Convert.ToInt32(FkVelicina.Row.ItemArray[0]);
                a.FkVelicina = vfk;

                DataRowView FkProizvod = comboBox2.SelectedItem as DataRowView;
                int pro = Convert.ToInt32(FkProizvod.Row.ItemArray[0]);
                a.FkProizvod = pro;

                DataRowView FkKorisnik = comboBox3.SelectedItem as DataRowView;
                int oso = Convert.ToInt32(FkKorisnik.Row.ItemArray[0]);
                a.FkKorisnik = oso;


                a.Masa = textBox3.Text;
                a.PrvoUpijanje = textBox4.Text;
                a.DrugoUpijanje = textBox5.Text;
                a.TreceUpijanje = textBox6.Text;
                a.CetvrtoUpijanje = textBox7.Text;
                a.Povrat = textBox8.Text;
             
                a.Komentar = richTextBox1.Text;


                ctx.AnalizaUpijanjaRavna.Add(a);
                ctx.SaveChanges();


            }
        }

        private void TextBox7_TextChanged(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(textBox7.Text) && !String.IsNullOrEmpty(textBox14.Text))
            {

                if (Convert.ToDouble(textBox7.Text) > Convert.ToDouble(textBox14.Text))
                { textBox7.ForeColor = Color.Red; }
                else { textBox7.ForeColor = Color.BlueViolet; }

            }
        }
    }
}

//textBox1.Text = "(Novi)";
