﻿namespace ABL
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            this.label8 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.osobaTableAdapter = new ABL.analizaDataSetTableAdapters.OsobaTableAdapter();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.osobaBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.analizaDataSet17 = new ABL.analizaDataSet17();
            this.osobaBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.analizaDataSet5 = new ABL.analizaDataSet5();
            this.osobaBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.analizaDataSet1 = new ABL.analizaDataSet1();
            this.osobaTableAdapter1 = new ABL.analizaDataSet1TableAdapters.OsobaTableAdapter();
            this.velicinaTableAdapter = new ABL.analizaDataSet2TableAdapters.VelicinaTableAdapter();
            this.proizvodTableAdapter = new ABL.analizaDataSet3TableAdapters.ProizvodTableAdapter();
            this.lutkaTableAdapter = new ABL.analizaDataSet4TableAdapters.LutkaTableAdapter();
            this.osobaTableAdapter2 = new ABL.analizaDataSet5TableAdapters.OsobaTableAdapter();
            this.velicinaTableAdapter1 = new ABL.analizaDataSet6TableAdapters.VelicinaTableAdapter();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.velicinaBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.analizaDataSet14 = new ABL.analizaDataSet14();
            this.velicinaBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.analizaDataSet7 = new ABL.analizaDataSet7();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.lutkaBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.analizaDataSet16 = new ABL.analizaDataSet16();
            this.lutkaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.analizaDataSet4 = new ABL.analizaDataSet4();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.velicinaBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.analizaDataSet6 = new ABL.analizaDataSet6();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.velicinaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.analizaDataSet2 = new ABL.analizaDataSet2();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.proizvodBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.analizaDataSet15 = new ABL.analizaDataSet15();
            this.proizvodBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.analizaDataSet3 = new ABL.analizaDataSet3();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.osobaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.analizaDataSet = new ABL.analizaDataSet();
            this.velicinaTableAdapter2 = new ABL.analizaDataSet7TableAdapters.VelicinaTableAdapter();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.velicinaTableAdapter3 = new ABL.analizaDataSet14TableAdapters.VelicinaTableAdapter();
            this.proizvodTableAdapter1 = new ABL.analizaDataSet15TableAdapters.ProizvodTableAdapter();
            this.lutkaTableAdapter1 = new ABL.analizaDataSet16TableAdapters.LutkaTableAdapter();
            this.osobaTableAdapter3 = new ABL.analizaDataSet17TableAdapters.OsobaTableAdapter();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.osobaBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.osobaBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.osobaBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.velicinaBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.velicinaBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet7)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lutkaBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lutkaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.velicinaBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet6)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.velicinaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.proizvodBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.proizvodBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.osobaBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.Location = new System.Drawing.Point(308, 215);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(26, 20);
            this.label8.TabIndex = 51;
            this.label8.Text = "ID";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button2.Location = new System.Drawing.Point(1142, 668);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(144, 60);
            this.button2.TabIndex = 63;
            this.button2.Text = "Poništi zapis";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button1.Location = new System.Drawing.Point(890, 668);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(144, 60);
            this.button1.TabIndex = 62;
            this.button1.Text = "Spremi i zatvori";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label19.Location = new System.Drawing.Point(256, 718);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(78, 20);
            this.label19.TabIndex = 61;
            this.label19.Text = "Komentar";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label18.Location = new System.Drawing.Point(226, 653);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(108, 20);
            this.label18.TabIndex = 60;
            this.label18.Text = "Analizu izvršio";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label16.Location = new System.Drawing.Point(228, 511);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(106, 20);
            this.label16.TabIndex = 58;
            this.label16.Text = "Apsorpcija (g)";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label15.Location = new System.Drawing.Point(97, 464);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(237, 20);
            this.label15.TabIndex = 57;
            this.label15.Text = "Masa pelene nakon cijeđenja (g)";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label14.Location = new System.Drawing.Point(172, 426);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(162, 20);
            this.label14.TabIndex = 56;
            this.label14.Text = "Masa suhe pelene (g)";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label13.Location = new System.Drawing.Point(236, 383);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(98, 20);
            this.label13.TabIndex = 55;
            this.label13.Text = "Položaj lutke";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label12.Location = new System.Drawing.Point(265, 340);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(69, 20);
            this.label12.TabIndex = 54;
            this.label12.Text = "Proizvod";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label11.Location = new System.Drawing.Point(270, 297);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(64, 20);
            this.label11.TabIndex = 53;
            this.label11.Text = "Veličina";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label9.Location = new System.Drawing.Point(277, 254);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(57, 20);
            this.label9.TabIndex = 52;
            this.label9.Text = "Datum";
            // 
            // osobaTableAdapter
            // 
            this.osobaTableAdapter.ClearBeforeFill = true;
            // 
            // comboBox4
            // 
            this.comboBox4.DataSource = this.osobaBindingSource3;
            this.comboBox4.DisplayMember = "ime_prezime";
            this.comboBox4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(379, 645);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(319, 28);
            this.comboBox4.TabIndex = 64;
            this.comboBox4.ValueMember = "id_osoba";
            // 
            // osobaBindingSource3
            // 
            this.osobaBindingSource3.DataMember = "Osoba";
            this.osobaBindingSource3.DataSource = this.analizaDataSet17;
            // 
            // analizaDataSet17
            // 
            this.analizaDataSet17.DataSetName = "analizaDataSet17";
            this.analizaDataSet17.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // osobaBindingSource2
            // 
            this.osobaBindingSource2.DataMember = "Osoba";
            this.osobaBindingSource2.DataSource = this.analizaDataSet5;
            // 
            // analizaDataSet5
            // 
            this.analizaDataSet5.DataSetName = "analizaDataSet5";
            this.analizaDataSet5.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // osobaBindingSource1
            // 
            this.osobaBindingSource1.DataMember = "Osoba";
            this.osobaBindingSource1.DataSource = this.analizaDataSet1;
            // 
            // analizaDataSet1
            // 
            this.analizaDataSet1.DataSetName = "analizaDataSet1";
            this.analizaDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // osobaTableAdapter1
            // 
            this.osobaTableAdapter1.ClearBeforeFill = true;
            // 
            // velicinaTableAdapter
            // 
            this.velicinaTableAdapter.ClearBeforeFill = true;
            // 
            // proizvodTableAdapter
            // 
            this.proizvodTableAdapter.ClearBeforeFill = true;
            // 
            // lutkaTableAdapter
            // 
            this.lutkaTableAdapter.ClearBeforeFill = true;
            // 
            // osobaTableAdapter2
            // 
            this.osobaTableAdapter2.ClearBeforeFill = true;
            // 
            // velicinaTableAdapter1
            // 
            this.velicinaTableAdapter1.ClearBeforeFill = true;
            // 
            // comboBox1
            // 
            this.comboBox1.DataSource = this.velicinaBindingSource3;
            this.comboBox1.DisplayMember = "velicina";
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(379, 294);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(319, 28);
            this.comboBox1.TabIndex = 65;
            this.comboBox1.ValueMember = "id_velicine";
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.ComboBox1_SelectedIndexChanged);
            // 
            // velicinaBindingSource3
            // 
            this.velicinaBindingSource3.DataMember = "Velicina";
            this.velicinaBindingSource3.DataSource = this.analizaDataSet14;
            // 
            // analizaDataSet14
            // 
            this.analizaDataSet14.DataSetName = "analizaDataSet14";
            this.analizaDataSet14.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // velicinaBindingSource2
            // 
            this.velicinaBindingSource2.DataMember = "Velicina";
            this.velicinaBindingSource2.DataSource = this.analizaDataSet7;
            // 
            // analizaDataSet7
            // 
            this.analizaDataSet7.DataSetName = "analizaDataSet7";
            this.analizaDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(29, 73);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(64, 20);
            this.label6.TabIndex = 21;
            this.label6.Text = "Veličina";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(29, 32);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(69, 20);
            this.label5.TabIndex = 20;
            this.label5.Text = "Proizvod";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Controls.Add(this.label25);
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.textBox16);
            this.panel2.Controls.Add(this.textBox17);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Controls.Add(this.label28);
            this.panel2.Controls.Add(this.textBox18);
            this.panel2.Controls.Add(this.textBox19);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label24);
            this.panel2.Controls.Add(this.textBox3);
            this.panel2.Controls.Add(this.textBox15);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.textBox7);
            this.panel2.Controls.Add(this.textBox8);
            this.panel2.Location = new System.Drawing.Point(890, 252);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(495, 370);
            this.panel2.TabIndex = 49;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label25.Location = new System.Drawing.Point(29, 318);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(107, 20);
            this.label25.TabIndex = 33;
            this.label25.Text = "Max_retencija";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label26.Location = new System.Drawing.Point(29, 277);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(103, 20);
            this.label26.TabIndex = 32;
            this.label26.Text = "Min_retencija";
            // 
            // textBox16
            // 
            this.textBox16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox16.Location = new System.Drawing.Point(187, 320);
            this.textBox16.Name = "textBox16";
            this.textBox16.ReadOnly = true;
            this.textBox16.Size = new System.Drawing.Size(261, 26);
            this.textBox16.TabIndex = 31;
            // 
            // textBox17
            // 
            this.textBox17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox17.Location = new System.Drawing.Point(187, 279);
            this.textBox17.Name = "textBox17";
            this.textBox17.ReadOnly = true;
            this.textBox17.Size = new System.Drawing.Size(261, 26);
            this.textBox17.TabIndex = 30;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label27.Location = new System.Drawing.Point(29, 235);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(119, 20);
            this.label27.TabIndex = 29;
            this.label27.Text = "Max_apsorpcija";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label28.Location = new System.Drawing.Point(29, 194);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(115, 20);
            this.label28.TabIndex = 28;
            this.label28.Text = "Min_apsorpcija";
            // 
            // textBox18
            // 
            this.textBox18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox18.Location = new System.Drawing.Point(187, 237);
            this.textBox18.Name = "textBox18";
            this.textBox18.ReadOnly = true;
            this.textBox18.Size = new System.Drawing.Size(261, 26);
            this.textBox18.TabIndex = 27;
            // 
            // textBox19
            // 
            this.textBox19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox19.Location = new System.Drawing.Point(187, 196);
            this.textBox19.Name = "textBox19";
            this.textBox19.ReadOnly = true;
            this.textBox19.Size = new System.Drawing.Size(261, 26);
            this.textBox19.TabIndex = 26;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.Location = new System.Drawing.Point(29, 156);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 20);
            this.label7.TabIndex = 25;
            this.label7.Text = "Max_masa";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label24.Location = new System.Drawing.Point(29, 115);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(82, 20);
            this.label24.TabIndex = 24;
            this.label24.Text = "Min_masa";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox3.Location = new System.Drawing.Point(187, 158);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(261, 26);
            this.textBox3.TabIndex = 23;
            // 
            // textBox15
            // 
            this.textBox15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox15.Location = new System.Drawing.Point(187, 117);
            this.textBox15.Name = "textBox15";
            this.textBox15.ReadOnly = true;
            this.textBox15.Size = new System.Drawing.Size(261, 26);
            this.textBox15.TabIndex = 22;
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox7.Location = new System.Drawing.Point(187, 75);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(261, 26);
            this.textBox7.TabIndex = 18;
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox8.Location = new System.Drawing.Point(187, 34);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(261, 26);
            this.textBox8.TabIndex = 17;
            // 
            // comboBox3
            // 
            this.comboBox3.DataSource = this.lutkaBindingSource1;
            this.comboBox3.DisplayMember = "polozaj_lutke";
            this.comboBox3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(379, 380);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(319, 28);
            this.comboBox3.TabIndex = 47;
            this.comboBox3.ValueMember = "id_lutke";
            // 
            // lutkaBindingSource1
            // 
            this.lutkaBindingSource1.DataMember = "Lutka";
            this.lutkaBindingSource1.DataSource = this.analizaDataSet16;
            // 
            // analizaDataSet16
            // 
            this.analizaDataSet16.DataSetName = "analizaDataSet16";
            this.analizaDataSet16.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lutkaBindingSource
            // 
            this.lutkaBindingSource.DataMember = "Lutka";
            this.lutkaBindingSource.DataSource = this.analizaDataSet4;
            // 
            // analizaDataSet4
            // 
            this.analizaDataSet4.DataSetName = "analizaDataSet4";
            this.analizaDataSet4.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(379, 690);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(319, 78);
            this.richTextBox1.TabIndex = 45;
            this.richTextBox1.Text = "";
            // 
            // textBox12
            // 
            this.textBox12.BackColor = System.Drawing.SystemColors.Window;
            this.textBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox12.ForeColor = System.Drawing.Color.Blue;
            this.textBox12.Location = new System.Drawing.Point(379, 506);
            this.textBox12.Name = "textBox12";
            this.textBox12.ReadOnly = true;
            this.textBox12.Size = new System.Drawing.Size(319, 26);
            this.textBox12.TabIndex = 43;
            this.textBox12.TextChanged += new System.EventHandler(this.TextBox12_TextChanged);
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox5.Location = new System.Drawing.Point(379, 461);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(319, 26);
            this.textBox5.TabIndex = 42;
            this.textBox5.TextChanged += new System.EventHandler(this.TextBox5_TextChanged);
            this.textBox5.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.zabrana);
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox6.Location = new System.Drawing.Point(379, 423);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(319, 26);
            this.textBox6.TabIndex = 41;
            this.textBox6.TextChanged += new System.EventHandler(this.TextBox6_TextChanged);
            this.textBox6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.zabrana);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox2.Location = new System.Drawing.Point(379, 251);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(319, 26);
            this.textBox2.TabIndex = 40;
            // 
            // velicinaBindingSource1
            // 
            this.velicinaBindingSource1.DataMember = "Velicina";
            this.velicinaBindingSource1.DataSource = this.analizaDataSet6;
            // 
            // analizaDataSet6
            // 
            this.analizaDataSet6.DataSetName = "analizaDataSet6";
            this.analizaDataSet6.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1604, 112);
            this.panel1.TabIndex = 48;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.label1.Location = new System.Drawing.Point(374, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(641, 42);
            this.label1.TabIndex = 2;
            this.label1.Text = "APSORPCIJA I RETENCIJA ZUIKO";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(41, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(219, 109);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1604, 112);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // velicinaBindingSource
            // 
            this.velicinaBindingSource.DataMember = "Velicina";
            this.velicinaBindingSource.DataSource = this.analizaDataSet2;
            // 
            // analizaDataSet2
            // 
            this.analizaDataSet2.DataSetName = "analizaDataSet2";
            this.analizaDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(890, 221);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(165, 20);
            this.label4.TabIndex = 50;
            this.label4.Text = "Targeti _APR obrazac";
            // 
            // comboBox2
            // 
            this.comboBox2.DataSource = this.proizvodBindingSource1;
            this.comboBox2.DisplayMember = "proizvod";
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(379, 337);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(319, 28);
            this.comboBox2.TabIndex = 46;
            this.comboBox2.ValueMember = "id_proizvoda";
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.ComboBox2_SelectedIndexChanged);
            // 
            // proizvodBindingSource1
            // 
            this.proizvodBindingSource1.DataMember = "Proizvod";
            this.proizvodBindingSource1.DataSource = this.analizaDataSet15;
            // 
            // analizaDataSet15
            // 
            this.analizaDataSet15.DataSetName = "analizaDataSet15";
            this.analizaDataSet15.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // proizvodBindingSource
            // 
            this.proizvodBindingSource.DataMember = "Proizvod";
            this.proizvodBindingSource.DataSource = this.analizaDataSet3;
            // 
            // analizaDataSet3
            // 
            this.analizaDataSet3.DataSetName = "analizaDataSet3";
            this.analizaDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox1.Location = new System.Drawing.Point(379, 212);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(319, 26);
            this.textBox1.TabIndex = 39;
            // 
            // osobaBindingSource
            // 
            this.osobaBindingSource.DataMember = "Osoba";
            this.osobaBindingSource.DataSource = this.analizaDataSet;
            // 
            // analizaDataSet
            // 
            this.analizaDataSet.DataSetName = "analizaDataSet";
            this.analizaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // velicinaTableAdapter2
            // 
            this.velicinaTableAdapter2.ClearBeforeFill = true;
            // 
            // textBox9
            // 
            this.textBox9.BackColor = System.Drawing.SystemColors.Window;
            this.textBox9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox9.ForeColor = System.Drawing.SystemColors.WindowText;
            this.textBox9.Location = new System.Drawing.Point(379, 599);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(319, 26);
            this.textBox9.TabIndex = 68;
            this.textBox9.TextChanged += new System.EventHandler(this.TextBox9_TextChanged);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label20.Location = new System.Drawing.Point(235, 602);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(99, 20);
            this.label20.TabIndex = 70;
            this.label20.Text = "Retencija (g)";
            // 
            // textBox10
            // 
            this.textBox10.BackColor = System.Drawing.SystemColors.Window;
            this.textBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox10.ForeColor = System.Drawing.SystemColors.MenuText;
            this.textBox10.Location = new System.Drawing.Point(379, 554);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(319, 26);
            this.textBox10.TabIndex = 73;
            this.textBox10.TextChanged += new System.EventHandler(this.TextBox10_TextChanged);
            this.textBox10.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.zabrana);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label23.Location = new System.Drawing.Point(59, 557);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(275, 20);
            this.label23.TabIndex = 76;
            this.label23.Text = "Masa pelene nakon centrifugiranja (g)";
            // 
            // velicinaTableAdapter3
            // 
            this.velicinaTableAdapter3.ClearBeforeFill = true;
            // 
            // proizvodTableAdapter1
            // 
            this.proizvodTableAdapter1.ClearBeforeFill = true;
            // 
            // lutkaTableAdapter1
            // 
            this.lutkaTableAdapter1.ClearBeforeFill = true;
            // 
            // osobaTableAdapter3
            // 
            this.osobaTableAdapter3.ClearBeforeFill = true;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button3.Location = new System.Drawing.Point(1400, 135);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(180, 40);
            this.button3.TabIndex = 77;
            this.button3.Text = "Povratak na izbornik";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.Button3_Click);
            // 
            // Form4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1604, 881);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.comboBox4);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.textBox1);
            this.Name = "Form4";
            this.Text = "Form4";
            this.Load += new System.EventHandler(this.Form4_Load);
            ((System.ComponentModel.ISupportInitialize)(this.osobaBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.osobaBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.osobaBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.velicinaBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.velicinaBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet7)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lutkaBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lutkaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.velicinaBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet6)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.velicinaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.proizvodBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.proizvodBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.osobaBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.analizaDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label9;
        private analizaDataSetTableAdapters.OsobaTableAdapter osobaTableAdapter;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.BindingSource osobaBindingSource2;
        private analizaDataSet5 analizaDataSet5;
        private System.Windows.Forms.BindingSource osobaBindingSource1;
        private analizaDataSet1 analizaDataSet1;
        private analizaDataSet1TableAdapters.OsobaTableAdapter osobaTableAdapter1;
        private analizaDataSet2TableAdapters.VelicinaTableAdapter velicinaTableAdapter;
        private analizaDataSet3TableAdapters.ProizvodTableAdapter proizvodTableAdapter;
        private analizaDataSet4TableAdapters.LutkaTableAdapter lutkaTableAdapter;
        private analizaDataSet5TableAdapters.OsobaTableAdapter osobaTableAdapter2;
        private analizaDataSet6TableAdapters.VelicinaTableAdapter velicinaTableAdapter1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.BindingSource velicinaBindingSource2;
        private analizaDataSet7 analizaDataSet7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.BindingSource lutkaBindingSource;
        private analizaDataSet4 analizaDataSet4;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.BindingSource velicinaBindingSource1;
        private analizaDataSet6 analizaDataSet6;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.BindingSource velicinaBindingSource;
        private analizaDataSet2 analizaDataSet2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.BindingSource proizvodBindingSource;
        private analizaDataSet3 analizaDataSet3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.BindingSource osobaBindingSource;
        private analizaDataSet analizaDataSet;
        private analizaDataSet7TableAdapters.VelicinaTableAdapter velicinaTableAdapter2;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox15;
        private analizaDataSet14 analizaDataSet14;
        private System.Windows.Forms.BindingSource velicinaBindingSource3;
        private analizaDataSet14TableAdapters.VelicinaTableAdapter velicinaTableAdapter3;
        private analizaDataSet15 analizaDataSet15;
        private System.Windows.Forms.BindingSource proizvodBindingSource1;
        private analizaDataSet15TableAdapters.ProizvodTableAdapter proizvodTableAdapter1;
        private analizaDataSet16 analizaDataSet16;
        private System.Windows.Forms.BindingSource lutkaBindingSource1;
        private analizaDataSet16TableAdapters.LutkaTableAdapter lutkaTableAdapter1;
        private analizaDataSet17 analizaDataSet17;
        private System.Windows.Forms.BindingSource osobaBindingSource3;
        private analizaDataSet17TableAdapters.OsobaTableAdapter osobaTableAdapter3;
        private System.Windows.Forms.Button button3;
    }
}